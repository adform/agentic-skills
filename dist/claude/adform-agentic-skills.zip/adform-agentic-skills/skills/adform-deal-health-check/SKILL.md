---
name: adform-deal-health-check
description: >-
  Deal delivery health check for the Adform Flow DSP (via the Adform GraphQL MCP). Use when a
  programmatic trader wants to see performance and recent delivery for deals wired to a campaign
  and flag any deal with zero or near-zero impressions — a signal of deal setup, pricing, or
  publisher supply problems. Trigger on "deal health check", "which deals aren't delivering",
  "deals with zero impressions", "check my deals on campaign X", "deal delivery problems", "are
  my PMP deals serving". For deal and inventory discovery use adform-inventory-deals; for the
  bid-versus-win curve use adform-bid-landscape. Read-only.
---

# Adform deal health check

Retrieves deals attached to a campaign or advertiser, pulls recent delivery metrics, and surfaces
deals with low or zero delivery alongside likely causes. Read-only.

## Currency protocol

Deal records carry a `currencyCode` field directly on `BuyerDeal` — this is the floor price
currency for the deal itself. It may differ from the campaign currency if the deal was negotiated
in a different currency (e.g. a USD-denominated PMP deal running in a GBP campaign).

**Resolution rule:** Always include `currencyCode` when fetching deal records. Present the deal
floor price with its own currency, and separately present campaign spend figures with the campaign
currency. Do not mix the two.

**Response header:** Open the health check output with a currency note:
> Deal floor prices are shown in each deal's own currency. Campaign spend figures are in **GBP**
> (campaign currency).

---

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_execute` to run queries. Use `graphql_search` to
look up field names.

---

## Step 1 — Find deals

```graphql
{
  buyerDealListItems(
    filters: [{ fieldName: "buyerDeal.searchPhrase", operation: contains, values: [""] }]
    pagination: { offset: 0, limit: 50 }
  ) {
    buyerDeals {
      id dealId name type price currencyCode status startDate endDate
      inventorySource { id name }
      healthIndications { status }
      deliveryIndications {
        yesterday { transaction { bids winRate trackedAds clicks ctr ecpm } }
        last7Days { transaction { bids winRate trackedAds clicks ctr ecpm } }
      }
      assignedToLineItemsCount
    }
    totalCount
  }
}
```

## Step 2 — Check past traffic per deal

```graphql
{
  inventoryMarketplaceDealPastTraffic(
    deals: [{ inventoryId: 42, dealId: "12345" }]
  ) {
    dealId
    trafficCounts { cookies requests }
  }
}
```

## Step 3 — Deal group context (if applicable)

```graphql
{ buyerDealGroup(id: "12345") { id name status dealIds } }
```

---

## Reading the results

For each deal, check:

- `deliveryIndications.yesterday.transaction.trackedAds` — impressions yesterday; zero on an
  active deal signals a problem
- `healthIndications.status` — platform health flag
- `deliveryIndications.yesterday.transaction.winRate` — low win rate alongside zero impressions
  suggests the floor price is above market; size a fix with adform-bid-landscape
- `assignedToLineItemsCount` — zero means the deal is not yet wired to any line item

**Date range note:** `deliveryIndications` only supports fixed presets (`yesterday`, `last7Days`).
For deal performance over a longer date range, use `inventoryMarketplaceDealPastTraffic` for
volume counts, or pivot to `campaignDailyDeliveryIndications` with batched 30-day windows
filtered to line items carrying those deals — see adform-reporting for the batching pattern.

---

## Presenting

Open with the currency disclosure. Lead with deals showing zero or near-zero delivery alongside
their status and floor price (with its own currency). Then present a full table of all deals
with impressions, win rate %, and eCPM. Note the likely cause for each flagged deal and a
recommended next step — re-price via adform-bid-landscape, confirm line-item wiring via
adform-line-items, or check supply via adform-past-traffic.
