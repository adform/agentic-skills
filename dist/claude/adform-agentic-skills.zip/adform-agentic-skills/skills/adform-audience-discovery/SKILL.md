---
name: adform-audience-discovery
description: >-
  Audience discovery and exploration for Adform Flow DSP. Find and evaluate available audience
  segments including third-party marketplace audiences, first-party data segments, and audience
  categories. Ideal for campaign planning, audience research, and targeting strategy development.
  For inventory and deal opportunities, see inventory discovery; for line item targeting setup,
  see targeting configuration.
---

# Audience discovery

Explore and evaluate audience segments for campaign targeting. Covers third-party marketplace
audiences, first-party data segments, audience categories, and private marketplace deals.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_execute` to run queries. Use `graphql_search` to
discover available filter fields; use `graphql_introspect` for complex nested types.

---

## Currency protocol

`audienceMarketplaceListItems` accepts a `currencyCode` argument that performs live FX conversion
on all returned CPM prices (`price.cpm`, `price.lookalikeCpm`, `price.idFusionCpm`). The API
default is DKK — **never rely on this default**, as planners would otherwise see DKK-denominated
CPMs without any indication of the denomination.

**Resolution order — determine currency before every call:**

1. **Currency in the prompt** — if the user mentions a currency (e.g. "GBP", "euros", "dollars"),
   use that ISO 4217 code.
2. **Campaign in context** — if a campaign or advertiser has been referenced in the conversation,
   fetch `campaign { currency }` and use that to match audience CPMs to the campaign's budget.
3. **No context** — default to `EUR`. Do not ask; do not silently use DKK.

**Response header:** Always declare the currency before presenting any CPM figures:
> Audience CPM prices are shown in **EUR**.

**Note on `dataProvider.currencyCode`:** This is the data provider's native billing currency
(e.g. a US provider may bill in USD). It is independent of the query-level `currencyCode` — the
API converts from the provider's native currency to whichever currency you request. Always fetch
`dataProvider { id name currencyCode }` alongside price fields so the user can see the provider's
billing currency if it differs from the display currency.

---

## Marketplace audiences

Third-party audience segments from specialised data providers, covering demographics, interests,
and behaviours across a wide range of categories.

### Querying `audienceMarketplaceListItems`

> **Note:** Use the `audience.status` filter with a **limit of 100 or fewer** and a minimal
> field selection. Paginate with increasing `offset` (0, 100, 200, ...) to retrieve the full
> dataset, then filter by name or category client-side. Do not use `audience.name` contains
> filters or request extended fields (`composition`, `iabCategories`, `lookalikeCpm`,
> `idFusionCpm`) in the same call — keep the selection lean.

### Example query — paginated active audiences

```graphql
{
  audienceMarketplaceListItems(
    filters: [
      { fieldName: "audience.status", operation: eq, values: ["active"] }
    ]
    pagination: { offset: 0, limit: 100 }
    currencyCode: "EUR"
  ) {
    audiences {
      id
      name
      status
      dataProvider { id name }
      price { cpm }
    }
  }
}
```

Increment `offset` by 100 until no more results are returned. Apply name or category matching
client-side after fetching.

**Additional fields** (request in a separate, smaller call if needed):
- `price.cpm` — standard CPM in the requested currency
- `price.lookalikeCpm` — CPM for lookalike extension
- `price.idFusionCpm` — CPM for ID Fusion cross-device extension
- `composition.uidTotalCount` — absolute unique user count
- `composition.uidTotalCountBucket` — bucketed size estimate: `le20k`, `le50k`, `le150k`,
  `le250k`, `le500k`, `leInf`
- `dataProvider.pricing` — `max` or `sum` (how multi-provider CPMs aggregate)
- `dataProvider.currencyCode` — the provider's native billing currency

### Browsing data providers and categories

```graphql
{
  audienceMarketplaceListItems(
    pagination: { offset: 0, limit: 50 }
    currencyCode: "EUR"
  ) {
    dataProviders { id name currencyCode pricing }
    customCategories { id name parentId }
  }
}
```

---

## First-party data audiences

Segments built from your own website traffic, customer data, and campaign interactions.

```graphql
{
  buyerAudienceListItems(
    filters: [
      { fieldName: "buyerAudience.advertisers.advertiserIds", operation: intersects, values: ["71883"] }
    ]
    pagination: { offset: 0, limit: 50 }
  ) {
    buyerAudiences {
      id name status
      composition { uidTotalCount }
      stats { campaigns impressions lastImpressionDate }
      createdAt
    }
    totalCount
  }
}
```

First-party segment CPMs are not applicable — these are owned data and carry no marketplace
price. Focus on reach (`uidTotalCount`) and recent usage (`lastImpressionDate`) when evaluating
first-party segments.

---

## Audience categories

Browse the marketplace taxonomy to identify relevant categories before searching for segments:

```graphql
{
  audienceMarketplaceListItems(
    pagination: { offset: 0, limit: 100 }
    currencyCode: "EUR"
  ) {
    customCategories { id name parentId }
  }
}
```

---

## Estimating audience reach

To estimate audience reach, run a `mediaPlanForecastingKpis` forecast with the selected segments
applied — the `forecast { cookies }` field returns projected unique reach for the targeting
configuration.

---

## Strategic workflow

**Marketplace audience research:**
1. Browse categories and data providers to identify relevant taxonomy
2. Search for segments by name or category, with the campaign's currency applied
3. Evaluate CPM, audience size, and provider billing currency
4. Compare similar segments across providers on a like-for-like currency basis
5. Select segments that align with campaign goals and budget efficiency targets

**First-party strategy:**
1. List existing segments for the advertiser to understand available owned data
2. Review size, recency of use, and composition
3. Identify gaps where marketplace audiences could supplement first-party reach

---

## Best practices

- Always pass the campaign's currency to `audienceMarketplaceListItems` to ensure CPMs are
  directly comparable to the campaign budget
- Compare providers on a like-for-like currency basis — note when a provider's native billing
  currency differs from the display currency
- Evaluate audience size with caution at small buckets (`le20k`, `le50k`) — thin audiences
  may not deliver meaningful reach at scale
- Combine first-party and marketplace audiences where possible to reduce reliance on third-party
  data and improve targeting precision
- Ensure all audience data usage complies with applicable privacy regulations and consent frameworks
