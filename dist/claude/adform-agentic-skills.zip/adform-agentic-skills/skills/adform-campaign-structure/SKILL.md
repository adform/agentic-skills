---
name: adform-campaign-structure
description: >-
  Campaign structure review for the Adform Flow DSP (via the Adform GraphQL MCP). Use when a
  programmatic trader wants to see how a campaign is set up — walk the hierarchy of advertiser,
  campaign, orders, and RTB line items, with budgets, flight dates, status, and targeting. Trigger
  on "what's in this campaign", "show me the orders and line items under campaign X", "how is this
  campaign structured", "review the setup", "find the campaign for advertiser Y", "what line items
  are in here". For performance numbers use adform-campaign-performance; for optimisation
  suggestions on a plan use adform-media-plan-review. Read-only.
---

# Adform campaign structure

Walk a campaign's setup: advertiser → campaign → orders → RTB line items, with budgets, flight
dates, and status. Read-only.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `csaf_name_to_id_resolution` as the **preferred** tool to
resolve campaign or advertiser names to numeric IDs. Use `graphql_execute` to run queries. Use
`graphql_search` to look up field names; use `graphql_introspect` for complex nested types such
as `RtbLineItem` targeting and inventory. Build the hierarchy one level at a time rather than
in a single large query.

## Campaign type classification

`Campaign.subType` indicates the channel of a campaign:

- `subType: "Rtb"` — RTB-only campaign. Line items live under `rtbLineItems`.
- `subType: "Mixed"` — both direct and RTB line items can coexist.
- Any other value (`Display`, `Mobile`, `Email`, `SocialMedia`, `Affiliate`, `Google`,
  `Yahoo`, `Microsoft`, `Print`, `SearchAll`, `SearchNonApi`) — non-RTB. There are no RTB
  line items to list, so skip step 3 below for these. Use the direct line-item queries in
  adform-line-items instead.

Always select `subType` in step 1 so step 3 can branch.

## Known API quirks

- **Do not select `rtbLineItems` / `directLineItems` nested under `Campaign`.** Selecting
  `totalCount` on these connections from `campaign(id:)`, `campaigns(advertisers:)`, or
  `agencyListItems → campaigns` is not supported. This skill uses the root-level
  `rtbLineItems(orderIds:)` query instead, which works cleanly.
- **`agencyListItems` does not accept `status` as a filter field.** Not used by this skill,
  but flagged here so cross-skill workflows don't reach for it.

---

## Step 0 — Resolve campaign or advertiser name to ID (if needed)

If the user provides a name rather than a numeric ID, resolve it first:

**Resolve a campaign by name:**
```json
csaf_name_to_id_resolution({
  "filters": [
    { "field": "campaign.name", "operation": "eq", "values": ["Vodafone UK Brand Q3 2026"] }
  ]
})
```

**Resolve by partial name:**
```json
csaf_name_to_id_resolution({
  "filters": [
    { "field": "campaign.name", "operation": "contains", "values": ["Vodafone"] }
  ]
})
```

Use the returned numeric campaign ID or advertiser ID in the steps below.

---

## Step 1 — Find campaigns for an advertiser

```graphql
{
  campaigns(
    advertisers: "71883"
    status: Active
    offset: 0
    limit: 20
  ) {
    campaigns { id name status type subType advertiserId startDate endDate budget currency billingCode }
    totalCount
  }
}
```

## Step 2 — List orders under a campaign

```graphql
{
  orders(
    campaignId: "3993873"
    active: true
    offset: 0
    limit: 20
  ) {
    orders { id name startDate endDate budget active }
    totalCount
  }
}
```

## Step 3 — List RTB line items under an order

Only run this step for orders belonging to campaigns where `subType` is `"Rtb"` or `"Mixed"`.
For non-RTB campaigns, skip to direct line-item queries in adform-line-items.

```graphql
{
  rtbLineItems(
    orderIds: ["67890"]
    offset: 0
    limit: 20
  ) {
    lineItems { id name rtbLineItem { id environments orderId campaignId paused deleted } }
    totalCount
  }
}
```

## Step 4 — Get a single line item's full config (optional)

```graphql
{ rtbLineItem(id: "99999") { id name environments orderId campaignId paused deleted } }
```

For full targeting and inventory detail, use `graphql_introspect` on `RtbLineItem`,
`RtbLineItemInventory`, and `RtbLineItemAudience` before selecting deeper fields.

---

## Common patterns

- **Name to ID**: use `csaf_name_to_id_resolution` with `campaign.name` or `order.name` filter
  as the preferred resolution path before any ID-dependent query
- **Structure review**: run steps 0–3 in sequence to map the full hierarchy
- **Single entity**: use `campaign(id:)`, `order(id:)`, or `rtbLineItem(id:)` for a focused view
- **Targeting inspection**: `rtbLineItems(orderIds:)` returns inventory and targeting inline;
  introspect nested types to select the fields you need

## Presenting

Compact structured summary: the campaign line (status, `subType`, flight dates, budget,
currency), then orders, then line items grouped by order with paused/active state. Flag anything
worth noting for a setup review — paused line items, missing end dates, line items with no
inventory wired. For performance numbers use adform-campaign-performance.
