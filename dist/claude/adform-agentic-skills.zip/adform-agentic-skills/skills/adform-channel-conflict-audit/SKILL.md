---
name: adform-channel-conflict-audit
description: >-
  Direct-versus-RTB channel conflict audit for the Adform Flow DSP (via the Adform GraphQL MCP).
  Use when an adserver ops person wants to detect direct line items and RTB line items under the
  same campaign that target overlapping inventory simultaneously — internal competition that can
  inflate CPMs. Trigger on "channel conflict", "direct vs RTB overlap", "are direct and programmatic
  competing", "same inventory targeted twice", "internal auction conflict", "direct and RTB
  targeting the same domains". For full line-item config use adform-line-items. Read-only.
---

# Adform direct-versus-RTB channel conflict audit

Compares the targeting of direct and RTB line items under a campaign to surface overlap on the
same domains, audiences, or placements where both types are delivering simultaneously. Read-only.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_execute` to run queries. Use `graphql_introspect`
on `RtbLineItemAudience` and `DirectLineItem` to discover targeting field shapes.

## When this audit applies

Channel conflict only happens when a campaign hosts both direct AND RTB line items. Read the
parent campaign's `subType` before running the audit:

- `subType: "Mixed"` — both channels can coexist. Run the audit.
- `subType: "Rtb"` — RTB-only campaign by definition. No direct line items to conflict with. Skip.
- Any other value (`Display`, `Mobile`, etc.) — non-RTB campaign by definition. No RTB line
  items to conflict with. Skip.

```graphql
{ campaign(id: "3993873") { id name subType } }
```

If `subType` is not `"Mixed"`, return "no channel conflict possible — campaign is
[RTB-only / Direct-only]" and stop.

## Known API quirks

- This skill uses the root-level `rtbLineItems(orderIds:)` and `directLineItems(orderId:)`
  queries, which work cleanly. Do NOT replace them with a nested `campaign(id:) { rtbLineItems
  { totalCount } directLineItems { totalCount } }` shortcut to short-circuit the audit — that
  selection is not supported. Use `Campaign.subType` instead (see above).

---

## Step 1 — List RTB line items under the order

```graphql
{
  rtbLineItems(
    orderIds: ["67890"]
    offset: 0
    limit: 20
  ) {
    lineItems { id name rtbLineItem { id environments orderId campaignId paused } }
    totalCount
  }
}
```

## Step 2 — List direct line items under the order

> **Note:** `directLineItems(orderId:)` and `directLineItemDeliveryIndications(id:)` may not return
> results in all configurations. Use `agencyListItems` with `lineItem.type` filter as a
> fallback for listing direct line items. For individual direct line item detail, use
> `directLineItem(id:)` (singular).

```graphql
{
  directLineItems(
    orderId: "67890"
    pagination: { offset: 0, limit: 20 }
  ) {
    directLineItems { id name status }
    totalCount
  }
}
```

If either step returns zero line items, there is no conflict to compute — stop here.

## Step 3 — Get targeting detail for each

For RTB line items, use `graphql_introspect` on `RtbLineItemAudience` to select targeting
rules including domains, audience segments, and locations:

```graphql
{ rtbLineItem(id: "99999") { id targetings { id name bidMultiplier } inventories { id buyingType } } }
```

Resolve domain targeting list IDs to actual domains using adform-targeting-segments.

## Step 4 — Delivery confirmation

Only flag as a conflict when both sides are actively delivering in the same time window. Check
delivery indications for each line item:

```graphql
{ rtbLineItemDeliveryIndications(id: "99999") { status effectiveFlightDailyCost } }
```

---

## Method

1. Confirm the parent campaign's `subType == "Mixed"`; otherwise stop.
2. Gather direct and RTB line items under the order; retain only those currently delivering.
3. Compare targeting: shared domains (resolve both lists), overlapping audience segment IDs,
   overlapping placements.
4. Flag only intersections where both sides show active delivery — that is the real conflict.

## Presenting

Conflict table: the direct line item, the RTB line item, the overlap dimension (domains,
audience, or placement), and whether both are currently live. Lead with overlaps where both
sides are delivering. Recommend de-duplicating targeting to eliminate self-competition.
