---
name: adform-entity-browsing
description: >-
  Entity browsing and ID resolution for the Adform Flow DSP (via the Adform GraphQL MCP). Use
  when a programmatic trader needs to find, list, or resolve entities — advertisers, campaigns,
  orders, line items — by name or ID. Covers hierarchy browsing with delivery indications,
  name-to-ID lookup, and advertiser detail including labels, viewability, and domain settings.
  Trigger on "find advertiser X", "what's the ID for campaign Y", "list advertisers", "show me
  advertiser settings", "who manages this account", "resolve name to ID". For campaign and order
  configuration detail use adform-campaign-management; for line-item detail use adform-line-items.
  Read-only.
---

# Adform entity browsing and ID resolution

Find, list, and resolve Adform entities — advertisers, campaigns, orders, line items — by name
or ID. Browse the full hierarchy with delivery indications, or do quick name-to-ID lookups.
Read-only.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `csaf_name_to_id_resolution` for name-to-ID lookups.
Use `graphql_execute(query, variables)` to run GraphQL and `graphql_validate` to check a query
first. Always validate before executing. The queries below are **illustrative examples** — if a
field or input shape isn't shown, or a query fails validation, discover the current schema with
`graphql_search` (lighter, preferred) and fall back to `graphql_introspect` one call at a time
for complex input types, enum values, or union/interface resolution.

---

## 1. Name-to-ID lookup via csaf_name_to_id_resolution

Use `csaf_name_to_id_resolution` as the **primary** name→ID tool. It resolves entity names to
numeric IDs directly without needing a full GraphQL list query.

**Supported field paths:**
- `campaign.name` — resolve a campaign name to its ID
- `order.name` — resolve an order name to its ID
- `lineItem.name` — resolve a line item name to its ID
- `campaign.managerId` — resolve by manager
- `label.name` — resolve a label name (requires `advertiser_id` param for scoping)

**Resolve a campaign by name:**
```json
{
  "filters": [
    { "field": "campaign.name", "operation": "eq", "values": ["My Campaign Name"] }
  ]
}
```

**Resolve a line item by name (partial match):**
```json
{
  "filters": [
    { "field": "lineItem.name", "operation": "contains", "values": ["UK Display Q3"] }
  ]
}
```

**Resolve a label by name (advertiser-scoped):**
```json
{
  "filters": [
    { "field": "label.name", "operation": "eq", "values": ["Retargeting"] }
  ],
  "advertiser_id": 71883
}
```

Use the returned numeric ID in subsequent GraphQL queries.

**Fallback — reverse lookup (ID to name) via agencyListItems:**
```graphql
{
  agencyListItems(
    filters: [{ fieldName: "campaign.id", operation: in, values: ["123456", "789012"] }]
  ) {
    campaigns { id name }
  }
}
```

---

## 2. Hierarchy browser — campaigns by advertiser

```graphql
{
  agencyListItems(
    filters: [{ fieldName: "advertiser.id", operation: eq, values: ["71883"] }]
    pagination: { limit: 20, offset: 0 }
  ) {
    campaigns {
      id name status
      period { start end }
      createdAt billingCode currencyCode type subType
    }
  }
}
```

## 3. Hierarchy browser — line items by order

```graphql
{
  agencyListItems(
    filters: [{ fieldName: "order.id", operation: eq, values: ["456789"] }]
    pagination: { limit: 20, offset: 0 }
  ) {
    lineItems {
      id name type status buyingType channelTypes
      rtbSettings { environments buying { type price maxBidPrice } }
    }
  }
}
```

---

## 4. List advertisers

```graphql
{
  advertisers(
    status: active
    offset: 0
    limit: 20
  ) {
    advertisers { id name status type }
    totalCount
  }
}
```

## 5. Get advertiser detail

```graphql
{
  advertiser(id: "71883") {
    id name status type
    industryVerticalId timeZoneMappingId
    trackingDomain netAmountCalcMethod
  }
}
```

## 6. Get advertiser labels

```graphql
{ advertiserLabels(id: "71883") { labelGroups { id name labels { id name } } } }
```

## 7. Get RTB domain settings

```graphql
{
  rtbDomains(id: "71883") {
    includedDomainsSource
    excludedDomainsSource
    includedDomainsTemplateId
    excludedDomainsTemplateId
    includedDomains
    excludedDomains
    excludeUnknownDomains
  }
}
```

---

## Common patterns

- **Name to ID**: call `csaf_name_to_id_resolution` with the entity field path and name value
- **Label name to ID**: call `csaf_name_to_id_resolution` with `label.name` filter and `advertiser_id`
- **ID to name**: `agencyListItems` with a `campaign.id` or similar `in` filter
- **Hierarchy drill-down**: list advertisers → campaigns by advertiser → orders by campaign →
  line items by order
- **ID format**: advertiser, campaign, order, and line item IDs are numeric strings

## Presenting

Show entity name and ID, status, and relevant config fields. For hierarchy views, render as an
indented tree or table. Always include the numeric ID so the trader can cross-reference in the
Adform platform.
