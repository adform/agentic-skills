---
name: adform-inventory-availability-forecast
description: >-
  Forward inventory availability sizing for the Adform Flow DSP (via the Adform GraphQL MCP).
  Use when a planner wants to size future supply before launch — how much inventory is available
  through an advertiser's private deals over the next 30 days, or how large an open-auction
  opportunity is for a given geo, format, or publisher category. Trigger on "deal availability
  forecast", "how much inventory is available", "size the open auction opportunity", "PMP
  availability next 30 days", "available impressions by deal", "open auction inventory sizing".
  For a single line item's reach and KPI forecast use adform-reach-forecast; for an RTB
  CPM-versus-win curve use adform-bid-landscape; for observed-only volume use adform-past-traffic.
  Read-only.
---

# Adform inventory availability forecast

Projects forward supply two ways: across an advertiser's PMP deals using recent traffic as a
baseline, and across open-auction inventory by domain, filtered by geo and format. Read-only.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_execute` to run queries. Use `graphql_search` to
look up field names.

---

## Deal availability (PMP)

### Step 1 — Find the advertiser's deals

```graphql
{
  buyerDealListItems(
    pagination: { offset: 0, limit: 50 }
  ) {
    buyerDeals {
      id dealId name type price currencyCode status startDate endDate
      inventorySource { id name }
      healthIndications { status }
    }
    totalCount
  }
}
```

### Step 2 — Past traffic baseline per deal

```graphql
{
  inventoryMarketplaceDealPastTraffic(
    deals: [{ inventoryId: 42, dealId: "12345" }]
  ) {
    dealId
    trafficCounts { cookies requests }
  }
}
```

Note: `inventoryMarketplaceDealPastTraffic` takes `inventoryId: Int!` (integer, not string) and
`dealId: ID!`. The input type is `PastTrafficDealInput`.

Project forward: use mean daily requests from the last 30 days as a baseline for the forecast
horizon. State this is an extrapolation from observed supply.

---

## Open-auction sizing

Use `inventoryMarketplaceDomainPastTraffic`, which accepts a list of domain strings and an
optional `PastTrafficFilterInput`.

### Step 1 — Compile a domain list by publisher category

There is no API to enumerate all available domains; construct a representative list based on
the target market and format, grouped by publisher category.

Typical UK open-auction video domains by category:

| Category | Representative domains |
|---|---|
| News / general | theguardian.com, telegraph.co.uk, independent.co.uk, mirror.co.uk, express.co.uk, standard.co.uk, dailymail.co.uk |
| Tabloid / mass market | thesun.co.uk, metro.co.uk |
| Sport | skysports.com, sportbible.com |
| Entertainment / lifestyle | ladbible.com, buzzfeed.com, cosmopolitan.com, timeout.com |
| Parenting | mumsnet.com, netmums.com |
| Finance | thisismoney.co.uk |
| Aggregator | msn.com, yahoo.com |
| Broadcast | sky.com |

Adapt the list for other markets and formats. BBC, ITV, Channel 4 and similar broadcast
properties typically return zero cookies/requests — their video inventory is sold direct or
via private marketplace, not through the open auction on Adform.

### Step 2 — Past traffic per domain with geo + channel filter

```graphql
{
  inventoryMarketplaceDomainPastTraffic(
    domains: [
      "theguardian.com", "telegraph.co.uk", "independent.co.uk",
      "mirror.co.uk", "thesun.co.uk", "metro.co.uk",
      "skysports.com", "ladbible.com", "mumsnet.com", "msn.com"
    ]
    filters: {
      countryIds: [826]
      channels: [video]
      environments: [web]
    }
  ) {
    domain
    trafficCounts { cookies requests }
  }
}
```

`PastTrafficFilterInput` fields:
- `countryIds: [ID!]` — Adform numeric country IDs. UK = 826, IE = 372, DE = 276.
  Resolve others via adform-geo-reference.
- `channels: [InventoryMarketplaceForecastingChannel!]` — enum values: `display`, `video`,
  `audio`, `native`, `tv`, `inAppGame`, `dooh` 
- `environments: [InventoryMarketplaceForecastingEnvironment!]` — `web` or `app` 
- `bannerSizes: [String!]` — e.g. `["728x90", "300x250"]` 
- `categoryIds: [ID!]` — IAB category IDs
- `dspAdTypes: [InventoryMarketplaceForecastingDspAdType!]` 

`trafficCounts.cookies` = addressable unique users over the last 30 days.
`trafficCounts.requests` = total bid requests over the last 30 days.
Domains returning zero have no supply available in the open auction on Adform for that
channel/geo combination — inventory is likely behind direct deals or excluded from the exchange.

### Step 3 — Aggregate by publisher category

Group domain results into categories client-side. Sum `requests` per category for the volume
headline; use `cookies` for unique reach. To project a 30-day impression estimate, use total
`requests` directly (it already covers 30 days). For a shorter flight, divide by 30 for a
daily rate and multiply by the intended duration. State that this extrapolates recent observed
supply and is not a guaranteed delivery figure.

### Step 4 (optional) — SSP / exchange past traffic

If specific Adform inventory source IDs (integers) are known from deal or marketplace records
(these represent SSPs/exchanges, not publishers):

```graphql
{
  inventoryMarketplaceInventoryPastTraffic(
    inventoryIds: [42, 55]
    filters: { countryIds: [826], channels: [video] }
  ) {
    inventoryId
    trafficCounts { cookies requests }
  }
}
```

`inventoryIds` takes `[Int!]!` — integer values, not strings.

---

## Presenting

Deals: table with deal name, status, floor price, baseline daily requests, and projected
30-day available impressions.

Open auction: table by publisher category with total bid requests (30d), addressable cookies,
and a projected daily request rate. Lead with the headline total across all domains, then
rank categories by volume. Note any zero-traffic domains explicitly — they signal inventory
unavailable in the open auction. State that projections extrapolate recent supply and are
not delivery guarantees.
