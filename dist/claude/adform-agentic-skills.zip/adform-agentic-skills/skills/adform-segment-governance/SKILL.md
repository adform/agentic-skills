---
name: adform-segment-governance
description: >-
  First-party segment governance audit for the Adform Flow DSP (via the Adform GraphQL MCP). Use
  when a strategist wants to audit DMP and first-party segments for an advertiser — find stale or
  unused segments, review sizes, and validate segment builder rules for logic gaps such as missing
  recency windows or overly broad triggers. Trigger on "segment governance", "stale segments",
  "unused first-party segments", "segment builder rule validation", "flag bad segment rules",
  "which segments haven't been used", "audit our DMP segments". For segment browsing and taxonomy
  use adform-targeting-segments; for marketplace audiences use adform-audience-discovery. Read-only.
---

# Adform segment governance

Two governance jobs over first-party segments: enumerate segments with sizes and flag stale or
unused ones; inspect segment builder rules and flag logic weaknesses. Read-only.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_execute` to run queries. Use `graphql_introspect` 
on `BuyerAudienceListItem` and `BuyerAudience` to discover available fields including size and
composition.

---

## Step 1 — List buyer audiences for an advertiser

First try filtering by advertiser ID:

```graphql
{
  buyerAudienceListItems(
    filters: [{ fieldName: "buyerAudience.advertisers.advertiserIds", operation: intersects, values: ["71883"] }]
    pagination: { offset: 0, limit: 100 }
  ) {
    buyerAudiences {
      id name status
      composition { uidTotalCount }
      stats { campaigns impressions lastImpressionDate }
      createdAt
    }
    totalCount
  }
}
```

**Fallback if that returns empty:** the advertiser filter can return zero results even when segments exist (segments may not be registered against an advertiser ID in the DMP). Fall back to a name search using a known brand keyword:

```graphql
{
  buyerAudienceListItems(
    filters: [{ fieldName: "buyerAudience.searchPhrase", operation: contains, values: ["BrandName"] }]
    pagination: { offset: 0, limit: 100 }
  ) {
    buyerAudiences {
      id name status
      composition { uidTotalCount }
      stats { campaigns impressions lastImpressionDate }
      createdAt
    }
    totalCount
  }
}
```

## Step 2 — Get audience detail including builder rule

**Important:** Use `buyerAudiences` (the agency-scope list) with pagination, which exposes all `rule` fields reliably:

```graphql
{
  buyerAudiences(pagination: { offset: 0, limit: 50 }) {
    buyerAudiences {
      id name status ttl frequency idFusion lookalike
      rule { expression recalculable }
      createdAt updatedAt
    }
    totalCount
  }
}
```

Paginate with `offset: 50`, `100` etc. until all segments are retrieved. The `buyerAudience(id)` single-entity query can still be attempted first, but do not retry more than once — fall back to the list approach immediately if no data is returned.

---

## Identifying stale and unused segments

- **Zero `uidTotalCount`**: audience has no reach — either the rule is too narrow or data has
  expired
- **`lastImpressionDate` older than 30 days** (or null): segment has not contributed to recent
  delivery — check whether it is referenced in any active line item's targeting
- **`status` inactive**: segment is disabled

To check whether a segment is referenced by active line items, search for its ID in line item
targeting. Cross-reference using adform-line-items.

## Identifying rule weaknesses

Inspect `rule.expression` for:

**Recency and TTL issues**
- No recency window (`InLastDays` absent) — a segment with no time limit on historical events
  grows stale quickly
- TTL / recency mismatch — `InLastDays` far shorter than `ttl` means users enter on a tight
  signal but remain in the segment long after it's stale. A ratio above 3× (e.g. `InLastDays: 21` 
  with `ttl: 120`) is a flag. Suppression segments should have TTL ≤ 2× the recency window.
- Inconsistent recency across legs — AND rules where different legs use different `InLastDays` 
  values (e.g. impression leg: 21d, engagement leg: 14d) create logical gaps where a user
  qualifies via one leg but not the other.

**Logic issues**
- `recalculable: false` on active segments — the audience is frozen at last build and will not
  refresh even if the underlying campaigns continue serving. Flag any active segment with
  `recalculable: false` and a TTL longer than 7 days.
- `rule: null` — segment has no builder expression; it is either a manual upload or
  misconfigured. Treat as unknown and flag for clarification.
- Duplicate conditions — identical AND/NOT clauses within the same rule (e.g. the same
  placement excluded twice) indicate a copy-paste issue and should be cleaned up.

**Scope and breadth issues**
- Single broad event trigger with no additional AND conditions (e.g. any impression on a client
  site with no campaign or placement scoping)
- Over-narrow scope — click-only triggers, or impression triggers scoped to a single order ID
  or banner placement, produce negligible reach pools. Clicks typically yield 10–50× fewer UIDs
  than impressions for the same campaign.
- Engagement = 0 as a sole qualifier with no minimum impression count — a user who received one
  impression and did not engage qualifies, making the segment effectively "everyone served"
- Missing OR/AND structure that would be needed to build a meaningful audience

---

## Presenting

Single audit table with one row per segment, sorted by severity (critical first), covering:
name, status, TTL, reach (`uidTotalCount`), `recalculable`, and a plain-English issues summary.

Severity classification:
- **Critical**: zero reach on active segment; `rule: null`; not recalculable on a segment in
  live delivery
- **Warning**: TTL/recency mismatch (ratio > 3×); inconsistent recency across legs; duplicate
  conditions; `recalculable: false` on unused but active segment; reach < 1,000 for a
  suppression or retargeting use case
- **OK**: rule logic is sound, recency and TTL are consistent, reach is adequate

Lead with critical issues. Inactive segments can be grouped at the bottom and noted briefly —
they don't require immediate action unless reactivation is planned. Close with a summary of
the `recalculable: false` pattern if it appears across multiple segments, since it is typically
the single highest-impact fix available.
