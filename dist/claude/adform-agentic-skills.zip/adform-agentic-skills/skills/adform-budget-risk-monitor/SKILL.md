---
name: adform-budget-risk-monitor
description: >-
  Budget delivery risk monitor for the Adform Flow DSP (via the Adform GraphQL MCP). Use when a
  planner wants to identify budget at risk across a campaign — orders likely to under-deliver
  their budget and campaigns or orders tracking to overspend before the end date. Trigger on
  "budget risk", "which orders will under-deliver", "budget overspend alert", "projected final
  spend", "reallocate budget", "am I going to over or under spend", "budget pacing across orders".
  For a single entity's pacing verdict use adform-pacing-check; for why something is not
  delivering use adform-delivery-health. Read-only.
---

# Adform budget risk monitor

Sweeps orders under a campaign, compares planned vs current vs projected delivery, and flags
two risks: under-delivery (budget left on the table) and overspend (on track to exceed budget
before the end date). Read-only.

## Currency protocol

All monetary fields — `effectiveFlightTotalGoal`, `effectiveFlightTotalCost`,
`effectiveFlightDailyCost`, `effectiveFlightProjectedDelivery` — are denominated in the
campaign's own currency. Neither the campaign nor order delivery indication responses carry a
currency field; currency is held on the campaign record.

**Resolution rule:** Fetch `currency` from the campaign record (Step 0 or Step 1 below) and
carry it through to every monetary figure in the output. For multi-campaign sweeps, note that
different campaigns under the same advertiser may use different currencies — do not aggregate
spend across currencies without FX conversion.

**Response header:** Open every budget risk report with a currency disclosure, for example:
> Budget figures are in **EUR** (campaign currency).

For mixed-currency sweeps:
> Campaigns are in mixed currencies — see the Currency column. Risk totals are per currency.

---

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `csaf_name_to_id_resolution` to resolve campaign names to
numeric IDs before running the sweep. Use `graphql_execute` to run queries.

---

## Step 0 — Resolve campaign name to ID (if needed)

If the user provides a campaign name rather than a numeric ID, resolve it first:

```json
csaf_name_to_id_resolution({
  "filters": [
    { "field": "campaign.name", "operation": "eq", "values": ["Vodafone UK Brand Q3 2026"] }
  ]
})
```

Use the returned numeric campaign ID in all queries below.

---

## Step 1 — Fetch campaign metadata including currency

```graphql
{ campaign(id: "3993873") { id name currency startDate endDate budget } }
```

Retain the `currency` value — it applies to all monetary fields in subsequent steps.

## Step 2 — List orders

```graphql
{
  orders(
    campaignId: "3993873"
    active: true
    offset: 0
    limit: 20
  ) {
    orders { id name startDate endDate budget active }
    totalCount
  }
}
```

## Step 3 — Delivery indications per order

Run once per order ID:

```graphql
{
  orderDeliveryIndications(id: "67890") {
    status goalType
    effectiveFlightTotalGoal
    effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery
    effectiveFlightRemainingDelivery
    effectiveFlightDeviationPercentage
    effectiveFlightTotalCost
    effectiveFlightDailyCost
    effectiveBudgetFlightStartDate
    effectiveBudgetFlightEndDate
  }
}
```

## Step 4 — Campaign-level view (optional)

```graphql
{
  campaignDeliveryIndications(id: "3993873") {
    status goalType
    effectiveFlightTotalGoal effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery effectiveFlightDeviationPercentage
    effectiveFlightTotalCost effectiveFlightDailyCost
  }
}
```

## Step 5 — Daily trend for at-risk entities (optional)

Max 30-day window per call. For longer ranges, split into consecutive 30-day batches (up to
~13 months lookback) and stitch results client-side — see the adform-reporting skill for the
batching pattern.

```graphql
{
  orderDailyDeliveryIndications(
    ids: ["67890", "67891"]
    from: "2026-05-13"
    until: "2026-06-12"
  ) {
    id deliveryDate
    deliveryIndications { effectiveFlightDailyCost effectiveFlightDeviationPercentage status }
  }
}
```

---

## Reading the results

- **Under-delivery risk:** `effectiveFlightProjectedDelivery` materially below
  `effectiveFlightTotalGoal` (negative deviation beyond −10%) while the flight is active —
  reallocation candidate
- **Overspend risk:** deviation strongly positive, or daily cost trend implies budget exhaustion
  before the end date
- **Schedule gap:** `status: ScheduleGap` — currently outside an active flight, not a risk in
  itself unless the gap is unexpected

---

## Presenting

Open with the currency disclosure. Risk table: entity (order or campaign), currency, budget
goal, current spend, projected spend, deviation %, and a verdict — UNDER-DELIVERING,
OVER-DELIVERING, or ON TRACK. Lead with at-risk entities and the monetary amount at stake.
Suggest reallocating budget from under-delivering to over-delivering orders where it fits the
plan. For a single entity's detailed pacing use adform-pacing-check; for a blocked entity use
adform-delivery-health.
