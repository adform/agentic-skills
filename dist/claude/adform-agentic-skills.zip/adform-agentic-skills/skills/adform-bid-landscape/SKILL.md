---
name: adform-bid-landscape
description: >-
  RTB bid-landscape forecast for the Adform Flow DSP (via the Adform GraphQL MCP). Use when a
  programmatic trader wants the CPM-versus-win-rate curve for an RTB line item — what share of
  auctions they would win at each CPM, the win rate at their current CPM, and the reachable unique
  cookies and bid requests. Trigger on "what CPM do I need to win X percent of auctions", "bid
  landscape", "win rate at this CPM", "how much can I win for this budget", "is my bid high
  enough", "how many cookies can this line item reach". For plan-level impressions and KPIs use
  adform-reach-forecast; for observed recent volume use adform-past-traffic. Read-only.
---

# Adform bid landscape

The CPM-versus-win-rate curve for an RTB line item: what share of auctions you win at each CPM,
plus reachable cookies and requests. Use this to answer "what CPM do I need to win X%". Read-only.

## Currency protocol

The bid landscape response includes a `currency` field on `RtbLineItemForecastingBidLandscape`
that declares the currency of the returned CPM values. This is resolved server-side from the
`campaignId` supplied in the forecast input — no separate currency lookup is required.

**Resolution rule:** Always include `currency` in the `bidlandscape` selection. Surface it in the
output so the trader knows what currency the CPM recommendations are in.

**Response header:** Open every bid landscape output with a currency disclosure, for example:
> CPM values are in **GBP** (from campaign settings).

---

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_execute(query, variables)` to run and
`graphql_validate` to check a query first. Always validate before executing. The queries below are
**illustrative examples** — if a field or input shape is not shown, or a query fails validation,
discover the current schema with `graphql_search` (preferred) and fall back to
`graphql_introspect` for complex nested types.

---

## Building the input

`rtbLineItemForecasting(lineItem: ForecastingRtbLineItemInput!)` requires a complete line-item
shape. Build it by reading the live line item first, then mirroring its targeting, inventory,
pricing, periods, and environments into the input.

## Method

1. Read the live line item using `rtbLineItem(id:)` to get current targeting, inventory, and pricing
2. Mirror the complete line item structure into the `ForecastingRtbLineItemInput` payload
3. Run `rtbLineItemForecasting` with the mirrored input
4. Read `bidlandscape.currency` from the response to confirm the CPM denomination
5. Pair `cpms` and `winRates` arrays by index to read the CPM-vs-win-rate curve

## Inline execute examples

### Step 1 — Read the live line item

```graphql
{
  rtbLineItem(id: "99999") {
    id name environments orderId campaignId
    inventories { id buyingType deals { id bidPrice } }
    targetings { id name bidMultiplier }
  }
}
```

### Step 2 — Run the forecast

```graphql
{
  rtbLineItemForecasting(lineItem: {
    name: "Forecast"
    campaignId: "3993873"
    # mirror the full targeting and inventory from the live line item
  }) {
    bidlandscape {
      currency
      cpms
      winRates
      exact { winRate }
    }
  }
}
```

`cpms` and `winRates` are parallel arrays — pair index N of `cpms` with index N of `winRates`
to read the curve. The `exact` field gives the win rate at the line item's current CPM.

---

## Presenting

Open with the currency disclosure from `bidlandscape.currency`. Lead with the actionable answer:
the CPM needed to hit the trader's target win rate (interpolate the curve), then show the full
curve as context. State that forecasts are estimates and cross-check with adform-past-traffic
if volume looks unexpected.
