---
name: adform-bid-landscape
description: >-
  RTB bid-landscape forecast for the Adform FLOW DSP. Shows the CPM-versus-win-rate curve for an RTB line item —
  auction win share at each CPM and the reachable unique cookies and bid requests. Trigger on
  "what CPM do I need to win X percent of auctions", "bid landscape", "win rate at this CPM",
  "is my bid high enough", "how many cookies can this line item reach".
  For plan-level impressions and KPIs use adform-reach-forecast; for observed recent volume use
  adform-past-traffic. Read-only.
---

# Adform bid landscape

The CPM-versus-win-rate curve for an RTB line item: what share of auctions you win at each CPM,
plus reachable cookies and requests. Use this to answer "what CPM do I need to win X%". Read-only.

IDs for geo/device/content filters can be resolved via adform-classifier-lookup.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_execute(query, variables)` to run and
`graphql_validate` to check a query first. Always validate before executing. The queries below are
**illustrative examples** — if a field or input shape isn't shown, or a query fails validation,
discover the current schema with `graphql_search` (lighter, preferred) and fall back to
`graphql_introspect` one call at a time with ≥2s between calls for complex input types, enum
values, or union/interface resolution.

---

## Building the input

`rtbLineItemForecasting(lineItem: ForecastingRtbLineItemInput!)` needs a complete line-item
shape. Build it by reading the live line item first, then mirroring its targeting, inventory,
pricing, periods, and environments into the input.

## Method

1. Read the live line item using `rtbLineItem(id:)` (the `id` is the RTB setup ID from `rtbLineItems()`, not the placement ID) to get current targeting, inventory, and pricing
2. Mirror the complete line item structure into the `ForecastingRtbLineItemInput` payload
3. Run `rtbLineItemForecasting` with the mirrored input
4. Pair `cpms` and `winRates` arrays by index to read the CPM-vs-win-rate curve

## Inline execute examples

### Read the live line item

```graphql
{
  rtbLineItem(id: "99999") {
    id name environments orderId campaignId
    inventories { id buyingType deals { id bidPrice } }
    targetings { id name bidMultiplier }
  }
}
```

### Run the forecast

```graphql
{
  rtbLineItemForecasting(lineItem: {
    name: "Forecast"
    campaignId: "3993873"
    # mirror the full targeting and inventory from the live line item
  }) {
    cpms
    winRates
    reachableCookies
    reachableRequests
  }
}
```

`cpms` and `winRates` are parallel arrays — pair index N of `cpms` with index N of `winRates`
to read the curve.

---

## Presenting

Lead with the actionable answer: the bid cap needed to hit the trader's target win rate
(interpolate the curve), then show the full curve as context, and the reachable cookies and
requests for inventory sizing. State that forecasts are estimates and cross-check with
adform-past-traffic if volume looks unexpected.

**Important — check the pricing model first.** The bid landscape returns CPM values, but the
line item's buying type determines which cap the trader should adjust. Read the line item's
buying type before recommending a change. For example, a CPC line item has Max eCPC as the
primary cap and Max CPM as a safety ceiling — recommending a CPM increase when the eCPC is the
binding constraint will not help. See the pricing model table in adform-line-items.

---

## Supplementary: bid reason context via mcpStats

After sizing the CPM needed to win the target share of auctions, cross-check
with a mcpStats bid reason query. This shows whether current losses are
primarily price-driven (the bid landscape addresses this) or driven by other
factors (creative audit, targeting, budget) that a CPM increase alone will not
fix. Validated query:

```graphql
{
  mcpStats {
    totalRowCount
    totals
    columns {
      dimensions { bidReason { name } }
      metrics {
        rtbBids
        lostBids
        bidReasonCount
        impressions
        rtbWinRate
      }
    }
    rows(
      filter: {
        date: { from: "2026-06-01", to: "2026-06-30" }
        advertiser: { ids: ["2133936"] }
      }
      paging: { offset: 0, limit: 50 }
      sort: [{ column: 0, direction: desc }]
    )
  }
}
```

If the dominant bid reason is price-floor-related, the bid landscape CPM
recommendation is the primary fix. If non-price reasons dominate, flag them
to the trader alongside the CPM recommendation so they are not surprised that
raising the bid alone does not resolve the win rate shortfall.
