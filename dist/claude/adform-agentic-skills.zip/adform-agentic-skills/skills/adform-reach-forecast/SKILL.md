---
name: adform-reach-forecast
description: >-
  Media plan forecasting for Adform Flow DSP. Project campaign performance before launch including
  impressions, reach, spend, and optimal bid pricing to achieve your KPI targets. Ideal for
  campaign planning, budget allocation, and scenario analysis. For detailed line item bidding
  analysis, see bid landscape forecasting; for historical performance data, see past traffic analysis.
---

# Media plan reach forecast

Forecast campaign performance metrics including projected impressions, unique reach, estimated
spend, and maximum bid prices required to achieve specific KPI targets. This enables data-driven
campaign planning and budget optimisation.

## Currency protocol

The `mediaPlanForecastingKpis` query takes a `budget.currency` field as part of its input. All
monetary output — projected spend, `maxPrice` — is returned in that declared currency.

**Resolution rule:**

1. **Currency in the prompt** — if the user states a budget with a currency (e.g. "€10,000",
   "£50,000 GBP"), use that ISO 4217 code.
2. **Campaign in context** — if the forecast is for an existing campaign, fetch
   `campaign { currency }` and use that.
3. **No context** — ask the user: *"What currency should the forecast use for budget and spend
   figures? (e.g. EUR, GBP, USD)"*

Do not proceed with a forecast that includes monetary budget inputs without a confirmed currency.

**Response header:** Open every forecast output with a currency disclosure, for example:
> Forecast figures are in **EUR** (as specified).

---

## Overview

The forecasting system analyses targeting criteria, budget allocations, and schedule information
to generate projected performance. Forecasts are estimates based on current market conditions
and should be used as planning guides, not delivery guarantees.

**Processing time:** Complex forecasts may require 5–15 seconds. Allow the response to return
before making additional requests.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_validate` to check queries before execution. Use
`graphql_execute` to run forecast queries. Use `graphql_search` to discover available fields;
use `graphql_introspect` for complex nested types.

---

## Forecast parameters

**Required inputs:**
- **Advertiser ID** — numeric advertiser identifier
- **Time zone** — campaign time zone (e.g. `Europe/Berlin`, `Europe/London`)
- **Schedule** — start and end dates for the forecast period
- **Budget** — total budget amount and **currency** (ISO 4217)
- **Performance goal** — target KPI (e.g. click-through rate)
- **Targeting** — geographic locations, channels, and any audience segments

**Example configuration:**
```
Campaign: 1–14 April 2026
Budget: €10,000 (EUR)
Target: Germany (country ID 276)
Channels: Display, Native
Goal: 0.5% CTR
```

## Geographic targeting — country IDs

Use ISO 3166-1 numeric country codes for location targeting:

| Country | ID |
|---|---|
| Germany | 276 |
| United Kingdom | 826 |
| United States | 840 |
| France | 250 |
| Netherlands | 528 |
| Denmark | 208 |
| Sweden | 752 |
| Norway | 578 |

Resolve other countries via `countries(search: "name")` in adform-geo-reference.

---

## Forecast query

Build a `ForecastingKpisMediaPlanInput` from the confirmed parameters. If forecasting an existing
campaign, fetch it first and apply only the overrides the user has requested.

> **Variables pattern required:** `mediaPlanForecastingKpis` must be called using
> GraphQL variables (the `query` + `variables` two-argument form of `graphql_execute`). Inlining
> the input directly into the query body is not supported. Always use the named-variable
> pattern below.

```graphql
query ForecastScenario($mediaPlan: ForecastingKpisMediaPlanInput!, $currencyCode: CurrencyCode) {
  mediaPlanForecastingKpis(mediaPlan: $mediaPlan, currencyCode: $currencyCode) {
    ctr { kpi impressions spend maxPrice }
    forecast { impressions cookies }
  }
}
```

Variables (JSON):
```json
{
  "currencyCode": "EUR",
  "mediaPlan": {
    "advertiserId": "71883",
    "timeZoneId": "Europe/Berlin",
    "name": "Forecast scenario",
    "schedules": [{ "startDateTime": "2026-04-01T00:00:00", "endDateTime": "2026-04-14T23:59:59" }],
    "budget": { "currency": "EUR", "amount": 10000, "frequencyCappingRules": [] },
    "goals": { "kpis": [{ "performance": { "ctr": { "rate": 0.005 } } }] },
    "targeting": {
      "idFusionEnabled": true,
      "inventory": { "channels": ["display", "native"] },
      "targetingRuleGroups": [{
        "locations": [{
          "targetingMode": "include",
          "locations": { "countryIds": ["276"] }
        }]
      }]
    }
  }
}
```

Pass `currencyCode` as a top-level query variable — this controls the currency of `maxPrice` and
`spend` in the response. Channel and targeting mode values are strings in the variables JSON
(e.g. `"display"`, `"include"`). Omit `inventorySources` unless the user explicitly names
specific sources.

**Domain and app targeting format:** When configuring domain or app targeting in the variables
JSON, use `{ "targetingMode": "includeAll" }`. The `excludeUnknown` property is not supported.

---

## Understanding the results

| Field | Description |
|---|---|
| `ctr.kpi` | The target KPI rate specified |
| `ctr.impressions` | Projected impressions to achieve that KPI |
| `ctr.spend` | Estimated spend required (in budget currency) |
| `ctr.maxPrice` | Maximum bid price needed (in budget currency) |
| `forecast.impressions` | Total projected impressions at full budget |
| `forecast.cookies` | Projected unique audience reach |

---

## Scenario analysis

To compare budget or targeting scenarios, run multiple forecast calls with adjusted parameters:

- **Budget scenario:** change `budget.amount` — compare reach and spend efficiency
- **Geo scenario:** modify `targetingRuleGroups.locations` — see how reach changes by market
- **KPI scenario:** adjust the `ctr.rate` target — observe the trade-off between reach and bid price

---

## Presenting

Open with the currency disclosure. Present the headline metrics — projected impressions, unique
reach, estimated spend, and maximum bid price — clearly labelled with the currency. State
explicitly that these are estimates based on current market conditions. Suggest one or two
scenario variants if the initial result shows limited reach or an unexpectedly high bid
requirement.
