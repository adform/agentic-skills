---
name: adform-campaign-management
description: >-
  Campaign and order configuration for the Adform Flow DSP (via the Adform GraphQL MCP). Use
  when a programmatic trader needs to inspect campaign or order settings — full config, RTB
  budget and capping, labels, brand safety, delivery indications, daily delivery trends, or
  projected delivery plans. Trigger on "show me campaign X config", "what labels are on this
  campaign", "brand safety settings", "campaign RTB budget", "order details", "order delivery
  plan", "daily delivery for campaign". For entity browsing and ID resolution use
  adform-entity-browsing; for pacing verdicts use adform-pacing-check. Read-only.
---

# Adform campaign and order management

Inspect campaign and order configuration, RTB settings, labels, brand safety, delivery
indications, daily trends, and projected delivery plans. Read-only.

## Currency protocol

Campaign currency is held on `Campaign.currency` (ISO 4217, always present and non-null). All
monetary fields in delivery indications and budget settings are denominated in this currency.

**Resolution rule:** Always include `currency` when fetching a campaign record. Attach the
currency to every monetary figure — budget goals, spend totals, daily costs — before presenting
results.

**Response header:** Open any report containing monetary figures with a currency disclosure:
> All figures are in **GBP** (campaign currency).

---

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `csaf_name_to_id_resolution` to resolve campaign or order
names to numeric IDs before querying. Use `graphql_execute` to run queries. Use `graphql_search`
to look up field names; use `graphql_introspect` for complex nested types.

## Campaign type classification

Use `Campaign.subType` as the canonical RTB/Direct classifier. `subType: "Rtb"` is an RTB
campaign; any other value (`Display`, `Mobile`, `Mixed`, `Email`, `SocialMedia`, `Affiliate`,
`Google`, `Yahoo`, `Microsoft`, `Print`, `SearchAll`, `SearchNonApi`) is non-RTB. Always include
`subType` in any campaign selection — downstream decisions (which delivery queries to run, which
metrics to surface) branch on it.

## Known API quirks

- **`rtbLineItems` and `directLineItems` nested under `Campaign` are not supported.**
  Selecting `totalCount` on these connections from `campaign(id:)`, `campaigns(advertisers:)`,
  or `agencyListItems → campaigns` is not supported. Use `Campaign.subType` to classify, and
  the dedicated `rtbLineItems(orderIds:)` / `directLineItems(orderId:)` root queries when you
  need line-item detail.
- **`agencyListItems` does not accept `status` as a filter field.** Filter status client-side
  after fetching. Confirmed working filter field: `advertiser.id`.

---

## Resolving IDs before querying

All campaign and order queries require numeric IDs. If the user provides a name, resolve it
first using `csaf_name_to_id_resolution`:

**Resolve a campaign name:**
```json
csaf_name_to_id_resolution({
  "filters": [
    { "field": "campaign.name", "operation": "eq", "values": ["Vodafone UK Brand Q3 2026"] }
  ]
})
```

**Resolve an order name:**
```json
csaf_name_to_id_resolution({
  "filters": [
    { "field": "order.name", "operation": "contains", "values": ["Display UK"] }
  ]
})
```

---

## Campaign queries

### List campaigns

```graphql
{
  campaigns(
    advertisers: "71883"
    status: Active
    offset: 0
    limit: 20
  ) {
    campaigns { id name status type subType advertiserId startDate endDate budget currency billingCode }
    totalCount
  }
}
```

### Get campaign — full config

```graphql
{ campaign(id: "3993873") { id name status type subType advertiserId startDate endDate budget currency } }
```

### Get campaign RTB settings

```graphql
{
  campaignRtbSettings(id: "3993873") {
    budget { budget periodType pacingType goalType amount }
    budgetGoalType
    budgetPeriodType
    capping {
      type
      impressions
      period { type duration }
      viewability { type duration }
    }
    dsaTransparency { advertiserLegalName }
  }
}
```

### Get campaign labels

```graphql
{ campaignLabels(id: "3993873") { labelGroups { id name labels { id name } } } }
```

### Get campaign brand safety

```graphql
{ campaignBrandSafety(id: "3993873") { enabled providerId blockedCategories blockUncategorized } }
```

### Get campaign delivery indications — current pacing snapshot

**Precondition.** Only call `campaignDeliveryIndications` when ALL of:

- `subType == "Rtb"`
- `budget > 0`
- `endDate` is not more than 30 days in the past

Non-RTB campaigns do not support delivery indications; zero-budget campaigns will not return useful results.
If the campaign does not qualify, report pacing as N/A.

```graphql
{
  campaignDeliveryIndications(id: "3993873") {
    status goalType
    effectiveFlightTotalGoal effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery effectiveFlightDeviationPercentage
    effectiveFlightTotalCost effectiveFlightDailyCost
    effectiveBudgetFlightStartDate effectiveBudgetFlightEndDate
  }
}
```

Monetary fields (`effectiveFlightTotalCost`, `effectiveFlightDailyCost`) are in the campaign's
`currency`. Fetch `campaign { currency }` first.

### Get campaign daily delivery — time-series (max 30 days per call)

```graphql
{
  campaignDailyDeliveryIndications(
    ids: ["3993873"]
    from: "2026-05-13"
    until: "2026-06-12"
  ) {
    id deliveryDate
    deliveryIndications {
      effectiveFlightDailyCost
      effectiveFlightDeviationPercentage
      status
    }
  }
}
```

---

## Order queries

### List orders

```graphql
{
  orders(
    campaignId: "3993873"
    active: true
    offset: 0
    limit: 20
  ) {
    orders { id name startDate endDate budget active }
    totalCount
  }
}
```

### Get order

```graphql
{ order(id: "67890") { id name startDate endDate budget campaignId active } }
```

### Get order delivery indications

```graphql
{
  orderDeliveryIndications(id: "67890") {
    status goalType
    effectiveFlightTotalGoal effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery effectiveFlightDeviationPercentage
    effectiveFlightTotalCost effectiveFlightDailyCost
    effectiveBudgetFlightStartDate effectiveBudgetFlightEndDate
  }
}
```

Monetary fields are in the parent campaign's `currency`. Resolve via `campaign { currency }`.

### Get order daily delivery — time-series (max 30 days per call)

```graphql
{
  orderDailyDeliveryIndications(
    ids: ["67890"]
    from: "2026-05-13"
    until: "2026-06-12"
  ) {
    id deliveryDate
    deliveryIndications { effectiveFlightDailyCost effectiveFlightDeviationPercentage status }
  }
}
```

---

## Common patterns

- **Name to ID:** call `csaf_name_to_id_resolution` with `campaign.name` or `order.name` before
  any query requiring a numeric ID
- **Hierarchy navigation:** list campaigns → list orders (`campaignId`) → list line items
  (see adform-line-items)
- **Type-aware branching:** read `subType` on the parent campaign first, then choose which
  line-item skill to use (RTB vs direct)
- **Delivery monitoring:** use delivery indications for a point-in-time snapshot; use the daily
  variant for trends over up to 30 days

## Presenting

Open with a currency disclosure when presenting any monetary figures. Lead with status, `subType`,
and key config fields. For delivery, show goal vs current vs projected vs deviation %. For daily
trends, present chronologically and note any gaps or drops. Always include the numeric entity ID.
