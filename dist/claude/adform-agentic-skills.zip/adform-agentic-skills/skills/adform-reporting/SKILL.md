---
name: adform-reporting
description: >-
  Campaign delivery and spend reporting for Adform Flow DSP. Monitor current spend, pacing, budget
  flight status, and delivery projections for campaigns, orders, and line items. For performance
  analysis, use campaign performance monitoring; for delivery health, use delivery health checks.
---

# Campaign delivery reporting

Monitor campaign delivery, spend, and pacing metrics to track budget utilisation and delivery
performance against goals.

## Currency protocol

All monetary fields — `effectiveFlightTotalCost`, `effectiveFlightDailyCost`,
`effectiveFlightTotalGoal`, `effectiveFlightCurrentDelivery`, `effectiveFlightProjectedDelivery` —
are denominated in the campaign's own currency. Delivery indication responses carry no currency
field; currency is held on the campaign record.

**Resolution rule:** Always fetch the campaign's `currency` field (via `campaign(id:)` or
`campaigns(advertisers:)`) before presenting any spend figures. Carry it through to every row
in the output.

**Mixed-currency accounts:** When multiple campaigns are reported together and they span more
than one currency, present a currency column per row and do not produce a combined total. If a
normalised total is needed, apply FX rates from `currencyRate()` (adform-geo-reference) and
state clearly which rate and date was used.

**Response header:** Open every spend or delivery report with a currency disclosure:
> All figures are in **GBP** (campaign currency).

---

## Report metrics

- Current spend and budget utilisation
- Pacing status and delivery projections
- Budget flight progress and completion
- Daily delivery trends
- Line item delivery health indicators

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `csaf_name_to_id_resolution` to resolve entity names to
numeric IDs. Use `graphql_execute` to run queries. Use `graphql_search` to look up field names;
use `graphql_introspect` for complex nested types.

---

## Available queries

| Need | Query |
|---|---|
| Current spend, pacing, budget flight — campaign | `campaignDeliveryIndications(id)` |
| Current spend, pacing, budget flight — order | `orderDeliveryIndications(id)` |
| Current spend, pacing, budget flight — RTB line item | `rtbLineItemDeliveryIndications(id)` |
| Daily time-series (30-day window per call, batch for longer ranges) — campaigns | `campaignDailyDeliveryIndications(ids, from, until)` |
| Daily time-series (30-day window per call, batch for longer ranges) — orders | `orderDailyDeliveryIndications(ids, from, until)` |
| Daily time-series (30-day window per call, batch for longer ranges) — RTB line items | `rtbLineItemDailyDeliveryIndications(ids, from, until)` |
| Root-cause delivery health — RTB line item | `rtbLineItemDeliveryHealth(id)` |
| Projected delivery plan — campaign | `campaignDeliveryPlan(campaign: {...})` |
| Projected delivery plan — order | `orderDeliveryPlan(order: {...})` |
| Projected delivery plan — line item | `lineItemDeliveryPlan(lineItem: {...})` |

---

## 1. Campaign delivery indications — current pacing snapshot

Fetch campaign metadata including currency first, then delivery indications:

```graphql
{ campaign(id: "4221341") { id name currency } }
```

```graphql
{
  campaignDeliveryIndications(id: "4221341") {
    status
    goalType
    effectiveFlightTotalGoal
    effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery
    effectiveFlightRemainingDelivery
    effectiveFlightDeviationPercentage
    effectiveFlightTotalCost
    effectiveFlightDailyCost
    effectiveBudgetFlightStartDate
    effectiveBudgetFlightEndDate
    effectiveFlightPeriodType
  }
}
```

**Field reference:**
- `goalType`: `Money` | `Impressions` | `Clicks` | `Unlimited`
- `status`: `Active` | `ScheduleGap` | `Finished`
- `effectiveFlightCurrentDelivery` — spend/impressions/clicks delivered so far in this flight
- `effectiveFlightProjectedDelivery` — model-projected end-of-flight delivery
- `effectiveFlightDeviationPercentage` — negative = under-delivering; positive = over-delivering
- `effectiveFlightTotalCost` — monetary spend regardless of goal type (in campaign currency)
- `effectiveFlightDailyCost` — spend in the last day (in campaign currency)

**Pattern — branding report for an advertiser:**
1. `advertisers(search: "name")` → get advertiser ID
2. `campaigns(advertisers: "$advertiserId")` → get all campaign IDs, names, endDates, statuses, and **currencies**
3. **Pre-filter:** skip campaigns with `endDate` > 30 days ago, or `budget: 0` and not active
4. `campaignDeliveryIndications(id: "$campaignId")` for each filtered campaign, one at a time
5. Assemble results client-side, tagging each row with its campaign currency

---

## 2. Order delivery indications

Same field shape as campaign. One order at a time. Resolve the parent campaign's `currency`
to label monetary output.

```graphql
{
  orderDeliveryIndications(id: "99999") {
    status goalType
    effectiveFlightTotalGoal effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery effectiveFlightDeviationPercentage
    effectiveFlightTotalCost effectiveFlightDailyCost
    effectiveBudgetFlightStartDate effectiveBudgetFlightEndDate
  }
}
```

---

## 3. RTB line item delivery indications

Same field shape as campaign. One line item at a time. Resolve the parent campaign's `currency`
to label monetary output.

```graphql
{
  rtbLineItemDeliveryIndications(id: "88888") {
    status goalType
    effectiveFlightTotalGoal effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery effectiveFlightDeviationPercentage
    effectiveFlightTotalCost effectiveFlightDailyCost
    effectiveBudgetFlightStartDate effectiveBudgetFlightEndDate
  }
}
```

---

## 4. Daily delivery indications — time-series breakdown

One row per entity per day. **Maximum window: 30 days per call.** Accepts multiple IDs in a
single call — batch all campaign/order/line item IDs together to minimise round trips.

**Custom date ranges longer than 30 days — use batched windows:**

```
Example — 3-month range Mar 24 – Jun 22:
→ Batch 1: from "2026-03-24" until "2026-04-22"  (30 days)
→ Batch 2: from "2026-04-23" until "2026-05-22"  (30 days)
→ Batch 3: from "2026-05-23" until "2026-06-22"  (30 days)
```

Maximum lookback: **~13 months**. An empty `[]` response on a batch means no flight data for
that entity in that window; continue to the next batch.

```graphql
{
  campaignDailyDeliveryIndications(
    ids: ["4221341", "4221349", "4221354"]
    from: "2026-06-01"
    until: "2026-06-11"
  ) {
    id
    deliveryDate
    deliveryIndications {
      status
      goalType
      effectiveFlightCurrentDelivery
      effectiveFlightTotalCost
      effectiveFlightDailyCost
      effectiveFlightDeviationPercentage
    }
  }
}
```

Use `orderDailyDeliveryIndications` and `rtbLineItemDailyDeliveryIndications` with the same
argument shape for orders and line items respectively.

---

## 5. RTB line item delivery health — structured root-cause check

Returns a health verdict across six checks: schedule, pricing, budget, banner assignment, tag
creative audit, and advertiser industry vertical sensitivity. Each check returns `Ok`, `Warning`,
or `Critical`.

```graphql
{
  rtbLineItemDeliveryHealth(id: "88888") {
    status
    updatedAt
    indications {
      schedule { status }
      pricing { status }
      budget { status }
      bannerAssigned { status }
      tagCreativeAudit { status }
      advertiserIndustryVertical { status }
    }
  }
}
```

---

## 6. Delivery plan projections

Forward-looking projections for a campaign, order, or line item given its current settings.
Use `graphql_introspect` on `DeliveryPlanCampaignSettingsInput`, `DeliveryPlanOrderSettingsInput`,
or `DeliveryPlanLineItemSettingsInput` to discover required fields before calling.

---

## Presenting

Open with the currency disclosure. For a branding/campaign report: table with campaign name,
currency, goal type, flight dates, budget goal, current spend, projected spend, deviation %, and
status. Flag campaigns with deviation below −20% as under-delivering and above +10% as approaching
overspend. Sort by deviation ascending to surface the largest gaps first.

For daily breakdowns: show a day-by-day spend trend and note any days with zero daily cost as
delivery gaps. Label all monetary columns with the ISO 4217 currency code.
