---
name: adform-pacing-check
description: >-
  Delivery pacing check for the Adform Flow DSP (via the Adform GraphQL MCP). Use whenever a
  programmatic trader wants to know whether a campaign, order, or RTB line item is pacing
  correctly — on track vs under- or over-delivering against its budget flight, spend so far,
  projected delivery, deviation %, and whether it is in an active flight or a schedule gap.
  Trigger on "is campaign X pacing ok", "is this on track to spend its budget", "is it under or
  over delivering", "how much has this spent vs goal", "check pacing", "will it hit budget". For
  the root cause when something is not delivering use adform-delivery-health; for historical
  performance numbers use adform-campaign-performance. Read-only.
---

# Adform pacing check

Is it pacing? Pulls delivery indications — flight goal vs current vs projected vs remaining,
spend, deviation %, and status — at campaign, order, or line-item level. Read-only.

## Currency protocol

Monetary fields (`effectiveFlightTotalGoal`, `effectiveFlightCurrentDelivery`,
`effectiveFlightProjectedDelivery`, `effectiveFlightTotalCost`, `effectiveFlightDailyCost`) are
denominated in the entity's campaign currency. The delivery indication responses carry no currency
field of their own.

**Resolution rule:** Before presenting any spend figures, fetch the campaign's `currency` field
and display it alongside all monetary values. For campaigns, include `currency` in the Step 1
query. For orders and line items, resolve the parent campaign ID and fetch its `currency`.

**Response header:** Open every pacing report with a currency disclosure, for example:
> Pacing figures are in **GBP** (campaign currency).

---

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `csaf_name_to_id_resolution` to resolve entity names to
numeric IDs before running delivery queries. Use `graphql_execute` to run queries. Use
`graphql_search` to look up field names.

---

## Step 0 — Resolve entity name to ID (if needed)

If the user provides a campaign, order, or line item name rather than a numeric ID, resolve it
first using `csaf_name_to_id_resolution`:

**Resolve a campaign by name:**
```json
{
  "filters": [
    { "field": "campaign.name", "operation": "eq", "values": ["Vodafone UK Brand Q3"] }
  ]
}
```

**Resolve an order by name:**
```json
{
  "filters": [
    { "field": "order.name", "operation": "contains", "values": ["Display UK"] }
  ]
}
```

**Resolve a line item by name:**
```json
{
  "filters": [
    { "field": "lineItem.name", "operation": "contains", "values": ["Prospecting"] }
  ]
}
```

Use the returned numeric ID in all delivery indication queries below.

---

## Campaign pacing

Fetch `currency` alongside the pacing snapshot by combining a campaign metadata query with the
delivery indications call:

```graphql
{ campaign(id: "4221341") { id name currency } }
```

```graphql
{
  campaignDeliveryIndications(id: "4221341") {
    status
    goalType
    effectiveFlightTotalGoal
    effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery
    effectiveFlightRemainingDelivery
    effectiveFlightDeviationPercentage
    effectiveFlightTotalCost
    effectiveFlightDailyCost
    effectiveBudgetFlightStartDate
    effectiveBudgetFlightEndDate
    effectiveFlightPeriodType
  }
}
```

## Order pacing

```graphql
{
  orderDeliveryIndications(id: "67890") {
    status goalType
    effectiveFlightTotalGoal effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery effectiveFlightDeviationPercentage
    effectiveFlightTotalCost effectiveFlightDailyCost
    effectiveBudgetFlightStartDate effectiveBudgetFlightEndDate
  }
}
```

Also available from `agencyListItems`: `orders { currencyCode }` — include this to resolve
currency without a separate campaign query.

## RTB line item pacing

```graphql
{
  rtbLineItemDeliveryIndications(id: "99999") {
    status goalType
    effectiveFlightTotalGoal effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery effectiveFlightDeviationPercentage
    effectiveFlightTotalCost effectiveFlightDailyCost
    effectiveBudgetFlightStartDate effectiveBudgetFlightEndDate
  }
}
```

Resolve the parent campaign's `currency` via `campaign(id: campaignId) { currency }` to label
the monetary output.

## Direct line item pacing

Direct line items use `directLineItemDeliveryIndications`, not the RTB endpoint. The response
shape is simpler — primarily `status`. Do not call `rtbLineItemDeliveryIndications` on a direct
line item ID.

```graphql
{
  directLineItemDeliveryIndications(id: "67890") {
    status
  }
}
```

**Note:** `campaignDeliveryIndications` is not applicable for campaigns that contain only direct line
items or that have very low delivery history. If the call returns no data, mark pacing as N/A
and note that the campaign appears to be direct-only or has insufficient flight data.

## Daily trend — when did pacing change?

Max 30-day window per call. Also available as `orderDailyDeliveryIndications` and
`rtbLineItemDailyDeliveryIndications` with identical argument shapes.

```graphql
{
  campaignDailyDeliveryIndications(
    ids: ["4221341"]
    from: "2026-05-13"
    until: "2026-06-12"
  ) {
    id deliveryDate
    deliveryIndications {
      effectiveFlightDailyCost
      effectiveFlightDeviationPercentage
      status
    }
  }
}
```

---

## Reading the results

- `status: ScheduleGap` — currently outside an active flight; the most common reason for a
  delivery pause at a given moment
- `status: Finished` — flight is over; no further delivery expected
- `goalType: Unlimited` — no pacing target; deviation and period fields will not return
- Strongly negative deviation — under-pacing; shortfall = `totalGoal − projected`
- Strongly positive deviation — front-loading ahead of plan

For the root cause when a line item cannot serve at all (no creative, audit pending, pricing or
budget issue) use adform-delivery-health. For a CPM that would resolve an under-pacing pricing
issue use adform-bid-landscape.

## Presenting

Open with the currency disclosure. Lead with the verdict — on track / under-delivering /
over-delivering / in a schedule gap — then the numbers: spend vs goal, projected vs goal, and
deviation %. Label all monetary values with the campaign currency. Recommend a concrete next step.
