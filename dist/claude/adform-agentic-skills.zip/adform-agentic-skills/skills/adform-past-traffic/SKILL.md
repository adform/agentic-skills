---
name: adform-past-traffic
description: >-
  Past-traffic lookup for the Adform Flow DSP (via the Adform GraphQL MCP). Use when a
  programmatic trader wants to know how much real traffic a piece of inventory recently saw —
  unique cookies and bid requests for specific domains, mobile apps, deals, inventory sources, or
  RTB line items. Trigger on "how much traffic does domain X get", "what did this deal or app do
  recently", "is there enough volume on these domains", "past traffic for this inventory", "how
  many requests or cookies on bild.de". For a CPM-versus-win-rate forecast use
  adform-bid-landscape; for plan-level reach use adform-reach-forecast. Read-only.
---

# Adform past traffic

How much real traffic did this inventory recently see? Returns unique cookies and bid requests
for domains, apps, deals, inventory sources, or line items. Use this to ground a forecast in
observed reality before targeting. Read-only.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_execute` to run queries. Use `graphql_introspect`
on `PastTrafficFilterInput` if you need to narrow results by geo or format.

---

## Domain past traffic

```graphql
{
  inventoryMarketplaceDomainPastTraffic(
    domains: ["bild.de", "spiegel.de"]
  ) {
    domain
    trafficCounts { cookies requests }
  }
}
```

## App past traffic

```graphql
{
  inventoryMarketplaceAppPastTraffic(
    apps: [{ id: "com.example.app" }]
  ) {
    id
    trafficCounts { cookies requests }
  }
}
```

Pass the bundle ID string directly as `id`. The response field is `id`, not `bundleId`.

## Deal past traffic

```graphql
{
  inventoryMarketplaceDealPastTraffic(
    deals: [{ inventoryId: 42, dealId: "12345" }]
  ) {
    dealId
    trafficCounts { cookies requests }
  }
}
```

## Inventory source (SSP / exchange) past traffic

```graphql
{
  inventoryMarketplaceInventoryPastTraffic(inventoryIds: [42, 55]) {
    inventoryId
    trafficCounts { cookies requests }
  }
}
```

## RTB line item past traffic

This query requires the full `ForecastingKeyRtbLineItemInput` shape (same as
`rtbLineItemForecasting`), not a simple ID pair. Read the live line item first, then mirror its
full config into the input:

1. Fetch the line item via `rtbLineItem(id:)` to get targeting, inventory, pricing, periods,
   and environments
2. Build a `ForecastingKeyRtbLineItemInput` with `key: "my-label"` and the full
   `ForecastingRtbLineItemInput` shape
3. Call `rtbLineItemPastTraffic` with the constructed input

```graphql
{
  rtbLineItemPastTraffic(
    lineItems: [{ key: "li-99999", lineItem: { /* full ForecastingRtbLineItemInput */ } }]
  ) {
    key
    trafficCounts { cookies requests }
  }
}
```

Use `graphql_introspect` on `ForecastingKeyRtbLineItemInput` and `ForecastingRtbLineItemInput`
to discover the required input shape. See adform-bid-landscape for the same pattern.

## Deal plus line item past traffic

```graphql
{
  dealLineItemPastTraffic(
    inventorySourceId: "42"
    dealId: "12345"
    lineItemId: "99999"
  ) {
    levels { key name group availableImpressions }
  }
}
```

---

## Presenting

Report cookies and requests per inventory item and translate into something actionable: is there
enough volume to support the planned budget and impression target? Flag thin inventory. If the
trader then wants a deliverability or CPM estimate, use adform-reach-forecast or
adform-bid-landscape.
