---
name: adform-campaign-performance
description: >-
  Campaign performance overview for Adform Flow DSP. Portfolio-level view of campaign delivery
  and performance metrics including spend, pacing, CTR, viewability, and eCPM. Stats available
  for yesterday, last 7 days, last 30 days (default), and last 13 months. For delivery health
  issues use delivery health checks; for creative details use tracking and tag inspection.
---

# Campaign performance overview

Portfolio-level campaign performance metrics including delivery, spend, pacing, and key performance
indicators across all campaigns for an advertiser.

## Currency protocol

All monetary fields — `costAmount`, `rtbSpendAmount`, `ecpmAmount`, `effectiveFlightTotalCost`,
`effectiveFlightDailyCost` — are denominated in the campaign's own currency. There is no
currency field on the delivery indications or stats responses themselves; currency is held on
the campaign record.

**Resolution rule:** Always include `currency` when listing campaigns (Step 1 below). Attach the
resolved currency to every spend figure before presenting results.

**Mixed-currency accounts:** When an advertiser runs campaigns in more than one currency (e.g. GBP
and EUR), do not produce a combined total row — totals across currencies are not meaningful without
FX conversion. Present results per campaign and note the currency on each row. If the user requests
a normalised total, use `currencyRate(sourceCurrencyCode, targetCurrencyCode)` from
adform-geo-reference to convert each campaign's spend to a common currency, and state clearly
which rate and date was applied.

**Response header:** Open every monetary report with a one-line currency disclosure, for example:
> All figures are in **GBP** (campaign currency).

or for mixed accounts:
> Campaigns are in mixed currencies — see the Currency column. Totals are not comparable across rows.

---

## Available metrics

- Current spend and budget utilisation
- Pacing status and delivery projections
- Budget deviation and flight progress
- Delivery schedule status
- CTR (click-through rate)
- Viewability rate (`viewableImpressionsRate`)
- eCPM (effective cost per mille)
- Historical performance data with multiple time intervals
- Period-over-period comparisons

## Data access

Performance metrics are available through `ListItemStatsIntervalDeliveryIndications`
with pre-built intervals via agency list items:

**Available intervals:**
- `yesterday` — previous day
- `last7days` — rolling 7 days
- `last30days` — rolling 30 days (**default** — use this unless the user specifies otherwise)
- `last13months` — rolling 13 months

Use `last30days` when no time range is specified. Use `last13months` only when the user
explicitly asks for a longer historical view.

**Custom date ranges — batched 30-day windows**

`agencyListItems` intervals are fixed presets and cannot be narrowed to a custom date range.
When the user asks for a specific date range (e.g. "last 3 months", "Q1", "Jan–Mar"), use
`campaignDailyDeliveryIndications` with explicit `from`/`until` dates instead. This query
accepts all campaign IDs in a single call but is capped at a **30-day window per call**.

For ranges longer than 30 days, split into consecutive 30-day batches and stitch results
client-side:

```
Range requested: 3 months (e.g. Mar 24 – Jun 22)
→ Batch 1: from "2026-03-24" until "2026-04-22"
→ Batch 2: from "2026-04-23" until "2026-05-22"
→ Batch 3: from "2026-05-23" until "2026-06-22"
```

Maximum lookback supported: **~13 months** (matching the `last13months` preset). Batches
beyond that will return empty. Run all batches in sequence, then aggregate `effectiveFlightDailyCost`
per campaign across batches before presenting totals.

**Empty batch handling:** A batch returning `[]` is expected for campaigns with `budget: 0`
or no active flight in that window. Continue to the next batch.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `csaf_name_to_id_resolution` to resolve advertiser or
campaign names to IDs before running queries. Use `graphql_execute` to run queries. Use
`graphql_search` to look up field names; use `graphql_introspect` for complex nested types.

## RTB vs Direct — classifying campaigns

Use the `Campaign.subType` enum field directly. It is the canonical classifier.

- `subType: "Rtb"` → RTB campaign
- `subType: "Display"` / `"Mobile"` / `"Mixed"` / `"Email"` / `"SocialMedia"` / `"Affiliate"` /
  `"Google"` / `"Microsoft"` / `"Yahoo"` / `"Print"` / `"SearchAll"` / `"SearchNonApi"`
  → Direct / non-RTB

Include `subType` in every campaign-listing query so downstream steps can branch on it.

**Do not** classify by selecting `rtbLineItems { totalCount }` or `directLineItems { totalCount }`
— see "Known API quirks" below. Do not classify by name pattern: naming conventions vary across
advertisers and break outside template-cloned campaign trees.

## Known API quirks

- **`rtbLineItems` and `directLineItems` nested under `Campaign` are not supported.**
  Selecting `totalCount` on these connections from `campaign(id:)`, `campaigns(advertisers:)`, or
  `agencyListItems → campaigns` is not supported. Use `Campaign.subType` for type classification;
  use the dedicated line-item skills if you need line-item counts or detail.
- **`agencyListItems` does not accept `status` as a filter field.** Filter status client-side
  after fetching. Confirmed working filter field: `advertiser.id`.

## Delivery indication call guidelines

`campaignDeliveryIndications` accepts only one ID at a time. For advertisers with large campaign
counts (100+), always pre-filter to avoid unnecessary calls on inactive or non-RTB campaigns.

**Pre-filter rule.** A campaign qualifies for a `campaignDeliveryIndications` call only when ALL
of the following are true:

1. `subType == "Rtb"` — non-RTB campaigns do not support delivery indications and must be skipped.
2. `budget > 0` — zero-budget campaigns have no flight data.
3. `endDate` is not more than 30 days in the past.

If any condition fails, mark pacing and flight fields as N/A for that campaign and continue.

**Graceful handling.** If `campaignDeliveryIndications` returns no data despite passing the
filter, mark pacing and flight fields as N/A and continue. Never abort a full run on a single
campaign. KPI stats via `agencyListItems` are fetched independently and will return
correctly for all campaigns.

---

## The pattern

### Step 0 — Resolve scope

If the user provides an advertiser or campaign name, resolve it first:

```json
csaf_name_to_id_resolution({
  "filters": [
    { "field": "campaign.name", "operation": "contains", "values": ["Vodafone"] }
  ]
})
```

Or use the GraphQL advertiser search:

```graphql
{
  advertisers(search: "Vodafone", status: active, offset: 0, limit: 5) {
    advertisers { id name }
    totalCount
  }
}
```

If no name was provided, call `advertisers(limit: 50)` and present the list for the user to
select. Do not silently fan out across all advertisers — confirm first, as a portfolio rollup
multiplies call volume by the number of active RTB campaigns.

### Step 1 — List campaigns

Always include `subType`, `budget`, `endDate`, and `currency` in the selection. These fields
drive the pre-filter in Step 3 and resolve the currency for all monetary output.

```graphql
{
  campaigns(
    advertisers: "2247935"
    limit: 50
    offset: 0
  ) {
    campaigns { id name status subType startDate endDate budget currency }
    totalCount
  }
}
```

If `totalCount == 0`, stop and inform the user that the advertiser has no campaigns.

### Step 2 — KPI stats via agencyListItems

Pull viewability, CTR, eCPM, and other KPIs in a single call per advertiser. Do not mix in
line-item selections (not supported; see Known API quirks).

```graphql
{
  agencyListItems(
    filters: [{ fieldName: "advertiser.id", operation: eq, values: ["71883"] }]
    pagination: { limit: 50, offset: 0 }
  ) {
    campaigns {
      id name status currencyCode
      deliveryIndications {
        stats {
          last30days {
            viewableImpressionsRate
            viewableImpressions
            ctr
            ecpmAmount
            trackedAds
            clicks
            rtbWinRate
            costAmount
            rtbSpendAmount
          }
        }
      }
    }
  }
}
```

**Available KPI fields per interval:**
- `viewableImpressionsRate` — percentage of measured impressions that were viewable
- `viewableImpressions` — absolute count of viewable impressions
- `ctr` — click-through rate
- `ecpmAmount` — effective CPM
- `ecpmvAmount` — effective CPM on viewable impressions
- `trackedAds` — total tracked ad impressions
- `clicks` — total clicks
- `rtbWinRate` — auction win rate
- `costAmount` — total cost (in campaign currency)
- `rtbSpendAmount` — RTB spend (in campaign currency)

Replace `last30days` with `yesterday`, `last7days`, or `last13months` as needed.

### Step 3 — Pre-filter for delivery indications

From the campaigns list in Step 1, retain only campaigns where ALL of:

- `subType == "Rtb"`
- `budget > 0`
- `endDate` ≥ today − 30 days

Run Step 4 for each qualifying campaign. Mark pacing fields as N/A for all others.

### Step 4 — Campaign delivery indications

Run once per filtered campaign ID.

```graphql
{
  campaignDeliveryIndications(id: "4221341") {
    status
    goalType
    effectiveFlightTotalGoal
    effectiveFlightCurrentDelivery
    effectiveFlightProjectedDelivery
    effectiveFlightRemainingDelivery
    effectiveFlightDeviationPercentage
    effectiveFlightTotalCost
    effectiveFlightDailyCost
    effectiveBudgetFlightStartDate
    effectiveBudgetFlightEndDate
  }
}
```

**Field reference:**
- `goalType`: `Money` | `Impressions` | `Clicks` | `Unlimited`
- `status`: `Active` | `ScheduleGap` | `Finished`
- `effectiveFlightDeviationPercentage` — negative = under-delivering; positive = over-delivering
- `effectiveFlightTotalCost` — monetary spend regardless of goal type (in campaign currency)

### Step 5 — Daily trend (optional)

For a day-by-day spend view across multiple campaigns (max 30-day window per call):

```graphql
{
  campaignDailyDeliveryIndications(
    ids: ["4221341", "4221349", "4221354"]
    from: "2026-06-01"
    until: "2026-06-11"
  ) {
    id
    deliveryDate
    deliveryIndications {
      effectiveFlightTotalCost
      effectiveFlightDailyCost
      effectiveFlightDeviationPercentage
      status
    }
  }
}
```

---

## RTB vs Direct campaign metric availability

| Metric | RTB (`subType: "Rtb"`) | Direct (all other subtypes) |
|---|---|---|
| `trackedAds` | valid | valid |
| `clicks` | valid | valid |
| `ctr` | valid | valid |
| `costAmount` | valid | valid (typically low — direct pricing model) |
| `ecpmAmount` | valid | present but near-zero / not meaningful |
| `viewableImpressionsRate` | valid | always 0 — no viewability signal on direct |
| `viewableImpressions` | valid | always 0 |
| `ecpmvAmount` | valid | always 0 |
| `rtbWinRate` | valid | always 0 — direct does not participate in RTB auctions |
| `rtbSpendAmount` | valid | always 0 |
| `campaignDeliveryIndications` | call only when `budget > 0` and `endDate` not >30d past | do not call |

**Rules:**
- Never flag `viewableImpressionsRate: 0` as anomalous on a direct campaign — it is structural.
- Omit `rtbWinRate`, `rtbSpendAmount`, `ecpmvAmount`, and `viewableImpressions` columns entirely
  from direct campaign rows.
- Do not call `campaignDeliveryIndications` on a non-RTB campaign.

---

## Presenting

Table with one row per campaign: name, type (RTB/Direct from `subType`), currency, goal type,
flight dates, budget goal, current spend, projected spend, deviation %, and status. Include an
account totals row only where all campaigns share the same currency. Flag campaigns with deviation
below −20% as under-delivering and above +10% as approaching overspend. Sort by deviation
ascending to surface the largest gaps first.

For mixed advertiser accounts (RTB + Direct), use separate sections or a clearly labelled type
column. Do not include RTB-only columns in direct campaign rows.
