---
name: adform-media-plans
description: >-
  Media plan inspection, forecasting, and AI recommendations for the Adform Flow DSP (via the
  Adform GraphQL MCP). Use when a programmatic trader needs to list media plans, inspect a plan's
  line items and settings, forecast reach and KPIs for a plan, or get AI-generated optimisation
  recommendations. Trigger on "media plans", "show me plan X", "forecast for this plan", "plan
  recommendations", "projected CTR or impressions or cookies", "budget scenario". For line-item
  detail use adform-line-items; for bid landscape on individual line items use adform-bid-landscape;
  for reach forecasting use adform-reach-forecast. Read-only.
---

# Adform media plans and forecasting

List, inspect, forecast, and get AI recommendations for media plans. Read-only.

## Currency protocol

Media plan budgets and forecast monetary outputs (projected spend, `maxPrice`) are denominated
in the currency specified in `budget.currency` within the forecast input.

**Resolution rule:**

1. **Currency in the prompt** — if the user states a budget with a currency (e.g. "€50,000",
   "£20k GBP"), use that ISO 4217 code.
2. **Existing plan in context** — if inspecting or forecasting from an existing media plan, fetch
   the plan's budget currency from `mediaPlan { budget { amount } }` and use `graphql_introspect`
   on `MediaPlanBudget` to confirm the currency field. Alternatively fetch the advertiser's
   active campaigns and use their `currency` as the default.
3. **No context** — ask the user: *"What currency should the plan budget and forecast use?
   (e.g. EUR, GBP, USD)"*

**Response header:** Open any forecast or budget output with a currency disclosure:
> Plan budget and forecast figures are in **EUR**.

---

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `graphql_execute` to run queries. Use `graphql_search` to
look up field names; use `graphql_introspect` for complex nested types.

Forecast queries can take 5–15 seconds on complex inputs — wait for the response and do not
retry before it returns.

---

## 1. List media plans

```graphql
{
  mediaPlans(
    advertiserIds: ["71883"]
    pagination: { offset: 0, limit: 20 }
  ) {
    mediaPlans { id name advertiserId comment budget { currency amount } }
  }
}
```

## 2. Get media plan — full detail

```graphql
{
  mediaPlan(id: "12345") {
    id name advertiserId comment
    budget { currency amount }
  }
}
```

Use `graphql_introspect` on `MediaPlan` to discover available sub-fields for goals, targeting,
schedules, and line items. Use `graphql_introspect` on `MediaPlanBudget` to confirm the currency
field name.

## 3. Forecast KPIs — projected CTR, impressions, cookies, spend

Build a `ForecastingKpisMediaPlanInput` from the plan details. Apply only the overrides the
trader has requested when forecasting an existing plan.

> **Variables pattern required:** `mediaPlanForecastingKpis` must be called using
> GraphQL variables (the `query` + `variables` two-argument form of `graphql_execute`). Inlining
> the input directly into the query body is not supported. Always use the named-variable
> pattern below.

```graphql
query ForecastScenario($mediaPlan: ForecastingKpisMediaPlanInput!, $currencyCode: CurrencyCode) {
  mediaPlanForecastingKpis(mediaPlan: $mediaPlan, currencyCode: $currencyCode) {
    ctr { kpi impressions spend maxPrice }
    forecast { impressions cookies }
  }
}
```

Variables (JSON):
```json
{
  "currencyCode": "EUR",
  "mediaPlan": {
    "advertiserId": "71883",
    "timeZoneId": "Europe/Berlin",
    "name": "Forecast scenario",
    "schedules": [{ "startDateTime": "2026-04-01T00:00:00", "endDateTime": "2026-04-14T23:59:59" }],
    "budget": { "currency": "EUR", "amount": 10000, "frequencyCappingRules": [] },
    "goals": { "kpis": [{ "performance": { "ctr": { "rate": 0.005 } } }] },
    "targeting": {
      "idFusionEnabled": true,
      "inventory": { "channels": ["display", "native"] },
      "targetingRuleGroups": [{
        "locations": [{
          "targetingMode": "include",
          "locations": { "countryIds": ["276"] }
        }]
      }]
    }
  }
}
```

Pass `currencyCode` as a top-level query variable — this controls the currency of `maxPrice` and
`spend` in the response. Channel and targeting mode values are strings in the variables JSON
(e.g. `"display"`, `"include"`). Omit `inventorySources` unless the user names specific sources.

**Domain and app targeting format:** Use `{ "targetingMode": "includeAll" }` in the variables
JSON. The `excludeUnknown` property is not supported.

## 4. Get AI optimisation recommendations

```graphql
{
  mediaPlanRecommendations(
    mediaPlan: { id: "12345" }
    filter: { types: [] }
  ) {
    recommendationGroup
    recommendationType
  }
}
```

Use `graphql_introspect` on `MediaPlanRecommendationsFilterInput` to discover available filter
types before calling.

---

## Common workflows

- **Plan review:** list plans → get plan detail → forecast KPIs → get recommendations
- **Budget scenario:** fetch plan → modify `budget.amount` in the forecast input → compare results
- **Geo scenario:** change `targetingRuleGroups.locations` in the forecast input → see reach change

## Presenting

Open with the currency disclosure. Show plan summary with name, status, and key settings.
For forecasts, present projected impressions, unique reach, estimated spend, and maximum bid
price — all labelled with the ISO 4217 currency code. For recommendations, list type and
description. State that forecasts are estimates based on current market conditions.
