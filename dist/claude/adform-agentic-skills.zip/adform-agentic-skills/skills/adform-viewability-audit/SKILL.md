---
name: adform-viewability-audit
description: >-
  Viewability settings consistency audit for the Adform Flow DSP (via the Adform GraphQL MCP).
  Use when an adserver ops person wants to confirm viewability measurement is configured
  consistently across an advertiser's campaigns — same approved settings — and flag deviations
  or line-level overrides that would make reporting inconsistent. Trigger on "viewability audit",
  "are viewability settings consistent", "check measurement standard", "viewability config across
  campaigns", "viewability override check". For general advertiser settings use
  adform-entity-browsing; for campaign config use adform-campaign-management. Read-only.
---

# Adform viewability settings audit

Reads the viewability capping configuration on campaigns and line items, compares it against
the agreed standard, and flags deviations or line-level overrides. Read-only.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `csaf_name_to_id_resolution` to resolve advertiser or
campaign names to numeric IDs before running the audit. Use `graphql_execute` to run queries.
Use `graphql_introspect` on `CampaignRtbSettings`, `RtbCappingSettings`, and
`ViewabilitySettings` to discover the current field shapes for viewability sub-objects.

Viewability is modelled as a capping setting — `type` and `duration` in
milliseconds — on `CampaignRtbSettings.capping[]` and on `RtbLineItem.impressionCappings[]`.
If your organisation tracks a viewability provider or percentage threshold separately, use
`graphql_search` with the terms "viewability" and "provider" to discover where those fields live.

---

## Step 0 — Resolve advertiser name to ID (if needed)

If the user provides an advertiser name rather than a numeric ID, resolve it first:

```json
csaf_name_to_id_resolution({
  "filters": [
    { "field": "campaign.name", "operation": "contains", "values": ["Vodafone"] }
  ]
})
```

Use the advertiser ID from the result to scope the campaign list below.

---

## Step 1 — List campaigns

```graphql
{
  campaigns(
    advertisers: "71883"
    status: Active
    offset: 0
    limit: 20
  ) {
    campaigns { id name status type subType advertiserId }
    totalCount
  }
}
```

**Direct campaign exclusion:** Viewability measurement only exists for RTB campaigns. Direct
campaigns always return `viewableImpressionsRate: 0` and `viewableImpressions: 0` — this is
structural, not a misconfiguration. Before running the audit, identify and exclude any direct
campaigns from the campaign list. A campaign is likely direct if its name contains "Direct" or
if it has no RTB line items (`rtbLineItems` returns empty). Only RTB campaigns should be
included in a viewability audit.

## Step 2 — Get viewability capping per campaign

```graphql
{
  campaignRtbSettings(id: "3993873") {
    capping {
      type
      impressions
      period { type duration }
      viewability { type duration }
    }
  }
}
```

The `viewability` sub-field contains `type` and `duration` (milliseconds). Compare these values
across campaigns to detect inconsistencies.

## Step 3 — Spot-check line-level overrides

```graphql
{ rtbLineItem(id: "99999") { id impressionCappings { frequency { impressions } } } }
```

Use `graphql_introspect` on `RtbLineItemCapping` to discover viewability-related capping
fields on individual line items.

---

## Method

1. Resolve advertiser name to ID via `csaf_name_to_id_resolution` if starting from a name
2. List campaigns and exclude direct campaigns
3. For each RTB campaign, read the viewability capping; flag any campaign whose type or duration
   differs from the baseline, or that has no viewability capping where one is expected
4. Spot-check line items for overrides that diverge from the campaign or baseline standard

## Presenting

Consistency table: campaign, viewability type, duration (ms), and a verdict — MATCHES, DEVIATES,
or NONE. Lead with deviations and missing measurement, as these break cross-campaign reporting
comparability. Note any line-level overrides separately. Recommend aligning to the agreed
standard.

If the advertiser has a mix of RTB and direct campaigns, note in the report header that direct
campaigns have been excluded from the audit as viewability measurement is not available for
direct inventory.
