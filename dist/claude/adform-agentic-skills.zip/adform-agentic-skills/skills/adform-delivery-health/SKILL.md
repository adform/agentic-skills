---
name: adform-delivery-health
description: >-
  Delivery health root-cause check for RTB line items on the Adform Flow DSP (via the Adform
  GraphQL MCP). Use when a programmatic trader needs to understand why a line item is not serving
  — runs structured checks on schedule, pricing, budget, banner assignment, creative audits, and
  advertiser vertical sensitivity, rolling them up to Ok, Warning, or Critical. Trigger on "why
  isn't my line item delivering", "what's wrong with this line item", "delivery health", "is there
  anything blocking this from serving", "no impressions at all from this line item". For whether
  something is merely pacing slowly use adform-pacing-check; for historical numbers use
  adform-campaign-performance. Read-only.
---

# Adform delivery health

Why is this RTB line item not serving? Runs Adform's structured health checks — schedule,
pricing, budget, banner assignment, creative audit, advertiser vertical — and rolls them up to
Ok, Warning, or Critical. Read-only.

## Connection & tooling

Runs on the Adform GraphQL MCP. Use `csaf_name_to_id_resolution` to resolve a line item name
to its numeric ID — this is the **preferred** resolution path. Use `graphql_execute` to run
queries. Use `graphql_search` or `graphql_introspect` to explore nested indication types.

---

## Step 0 — Resolve line item name to ID (if needed)

If the user provides a line item name rather than a numeric ID, resolve it first:

```json
csaf_name_to_id_resolution({
  "filters": [
    { "field": "lineItem.name", "operation": "contains", "values": ["UK Prospecting Display"] }
  ]
})
```

If the user provides a campaign name to search within:

```json
csaf_name_to_id_resolution({
  "filters": [
    { "field": "campaign.name", "operation": "eq", "values": ["Vodafone UK Brand Q3"] }
  ]
})
```

Then list line items under the resolved campaign ID to find the target:

```graphql
{
  rtbLineItems(campaignIds: ["3993873"], offset: 0, limit: 20) {
    lineItems { id name rtbLineItem { id paused } }
    totalCount
  }
}
```

As a last resort, ask the trader to provide the ID from the Adform platform URL.

---

## Delivery health query

**This endpoint is RTB-only.** `rtbLineItemDeliveryHealth` does not exist for direct line items.
If the user asks about delivery health for a direct line item, explain that the structured health
check is not available for direct inventory, and instead manually inspect the direct line item's
`status`, `periods`, and creative assignment via `directLineItem(id:)`.

```graphql
{
  rtbLineItemDeliveryHealth(id: "99999") {
    status
    updatedAt
    indications {
      schedule { status }
      pricing { status }
      budget { status }
      bannerAssigned { status }
      tagCreativeAudit { status }
      advertiserIndustryVertical { status }
    }
  }
}
```

Each indication returns `Ok`, `Warning`, or `Critical`. Use `graphql_introspect` on the
specific indication type to retrieve additional detail fields such as `reason`.

---

## Reading the checks

- `bannerAssigned` — no eligible creative assigned to the line item; cannot serve until a
  creative is attached
- `tagCreativeAudit` — creatives not yet approved by the targeted SSPs/exchanges
- `pricing` — bid or CPM too low to win auctions, or pricing model misconfigured; size a fix
  with adform-bid-landscape
- `budget` — budget exhausted or a budget configuration issue
- `schedule` — flight has ended, not yet started, or has a gap covering the current time
- `advertiserIndustryVertical` — sensitive-vertical restriction blocking certain inventory

---

## Presenting

Lead with the rolled-up status, then the specific failing check and a concrete recommended
action for the trader to apply — for example "assign an approved creative", "raise CPM to
approximately €X", or "the flight ended on DATE — extend the end date". This skill never
changes anything.

If the line item is serving but pacing slowly rather than blocked entirely, use
adform-pacing-check instead.
